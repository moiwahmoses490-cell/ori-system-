<?php
// includes/auth.php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Session Timeout Management (15 minutes / 900 seconds)
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 900)) {
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        session_start();
        $_SESSION['flash_error'] = "Your session has timed out due to inactivity. Please sign in again.";
        header("Location: /index.php");
        exit;
    }
    $_SESSION['last_activity'] = time();
}

/**
 * Check if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Restrict page access to logged-in users. Redirects to login page if not authenticated.
 */
function require_login() {
    if (!is_logged_in()) {
        header("Location: /index.php");
        exit;
    }
}

/**
 * Check if the logged-in user has a specific role or set of roles
 */
function has_role($roles) {
    if (!is_logged_in()) return false;
    
    $user_role = $_SESSION['user_role'] ?? '';
    if (is_array($roles)) {
        return in_array($user_role, $roles);
    }
    return $user_role === $roles;
}

/**
 * Restrict page access to specific roles. Redirects to unauthorized page or dashboard.
 */
function require_role($roles) {
    require_login();
    if (!has_role($roles)) {
        $_SESSION['flash_error'] = "Unauthorized access. You do not have permission to view that page.";
        header("Location: /pages/dashboard.php");
        exit;
    }
}

/**
 * Generate CSRF token
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>
