<?php
// includes/header.php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

require_login();

$current_page = basename($_SERVER['PHP_SELF']);
$user_role = $_SESSION['user_role'] ?? '';
$user_name = $_SESSION['user_name'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'SLeClear MIS'; ?> - Student Clearance & Financial MIS</title>
    
    <!-- Google Fonts: Inter & Outfit -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Main Style -->
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="app-container">
        <!-- Sidebar Navigation -->
        <aside class="sidebar">
            <div class="sidebar-brand">
                <div class="brand-icon">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
                <div class="brand-text">
                    <h1>SLeClear</h1>
                    <span>MIS Portal</span>
                </div>
            </div>
            
            <div class="user-profile-badge">
                <div class="avatar">
                    <?php echo strtoupper(substr($user_name, 0, 2)); ?>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo htmlspecialchars($user_name); ?></span>
                    <span class="user-role badge-role-<?php echo strtolower($user_role); ?>"><?php echo htmlspecialchars($user_role); ?></span>
                </div>
            </div>

            <nav class="sidebar-nav">
                <ul>
                    <li class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                        <a href="/pages/dashboard.php">
                            <i class="fa-solid fa-chart-pie"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    
                    <?php if (has_role(['Admin', 'Registry'])): ?>
                    <li class="<?php echo ($current_page == 'students.php' || $current_page == 'student_form.php') ? 'active' : ''; ?>">
                        <a href="/pages/students.php">
                            <i class="fa-solid fa-user-graduate"></i>
                            <span>Students</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (has_role(['Admin', 'Finance'])): ?>
                    <li class="<?php echo ($current_page == 'payments.php' || $current_page == 'payment_form.php') ? 'active' : ''; ?>">
                        <a href="/pages/payments.php">
                            <i class="fa-solid fa-receipt"></i>
                            <span>Payments</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <li class="<?php echo ($current_page == 'clearances.php' || $current_page == 'clearance_view.php') ? 'active' : ''; ?>">
                        <a href="/pages/clearances.php">
                            <i class="fa-solid fa-file-signature"></i>
                            <span>Clearances</span>
                        </a>
                    </li>
                    
                    <li class="<?php echo ($current_page == 'deferred.php' || $current_page == 'deferred_form.php') ? 'active' : ''; ?>">
                        <a href="/pages/deferred.php">
                            <i class="fa-solid fa-calendar-minus"></i>
                            <span>Deferred Exams</span>
                        </a>
                    </li>
                    
                    <?php if (has_role(['Admin', 'Finance'])): ?>
                    <li class="<?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                        <a href="/pages/reports.php">
                            <i class="fa-solid fa-file-invoice-dollar"></i>
                            <span>Financial Reports</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (has_role('Admin')): ?>
                    <li class="<?php echo $current_page == 'users.php' ? 'active' : ''; ?>">
                        <a href="/pages/users.php">
                            <i class="fa-solid fa-users-gear"></i>
                            <span>User Accounts</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <li class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                        <a href="/pages/profile.php">
                            <i class="fa-solid fa-user-cog"></i>
                            <span>My Profile</span>
                        </a>
                    </li>
                </ul>
            </nav>
            
            <div class="sidebar-footer">
                <a href="/api/logout.php" class="logout-btn">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>Sign Out</span>
                </a>
            </div>
        </aside>
        
        <!-- Main Content Wrapper -->
        <main class="main-content">
            <!-- Header Bar -->
            <header class="topbar">
                <div class="page-title-area">
                    <h2><?php echo $page_title ?? 'Dashboard'; ?></h2>
                    <p class="breadcrumbs">Portal / <?php echo str_replace('.php', '', ucfirst($current_page)); ?></p>
                </div>
                
                <div class="topbar-actions">
                    <div class="live-clock" id="live-clock">
                        <i class="fa-solid fa-clock"></i>
                        <span>Loading time...</span>
                    </div>
                    
                    <div class="quick-status">
                        <span class="status-indicator"></span>
                        <span class="status-label">System Online</span>
                    </div>
                </div>
            </header>
            
            <!-- Dynamic Page Content Container -->
            <div class="page-content">
                <?php echo display_flash_messages(); ?>
