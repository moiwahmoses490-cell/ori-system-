            </div> <!-- End .page-content -->
            
            <footer class="main-footer">
                <p>&copy; <?php echo date('Y'); ?> SLeClear MIS - University Financial Compliance & Decision Support. All Rights Reserved.</p>
                <div class="footer-links">
                    <span>Sierra Leone National EMIS Alignment</span>
                </div>
            </footer>
        </main> <!-- End .main-content -->
    </div> <!-- End .app-container -->
    
    <!-- Main JS -->
    <script src="/assets/js/app.js"></script>
    <script>
        // Update clock in topbar
        function updateClock() {
            const clockEl = document.getElementById('live-clock');
            if (clockEl) {
                const now = new Date();
                const timeString = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true });
                const dateString = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
                clockEl.querySelector('span').textContent = `${dateString} | ${timeString}`;
            }
        }
        setInterval(updateClock, 1000);
        updateClock();
    </script>
</body>
</html>
