<?php
// includes/functions.php

/**
 * Format currency to Sierra Leonean Leone (Le)
 */
function format_currency($amount) {
    return 'Le ' . number_format($amount, 2);
}

/**
 * Calculate student total payments
 */
function get_student_payments_total($pdo, $student_id) {
    $stmt = $pdo->prepare("SELECT SUM(amount) FROM payments WHERE student_id = ?");
    $stmt->execute([$student_id]);
    return (float) $stmt->fetchColumn();
}

/**
 * Calculate student balance
 */
function get_student_balance($pdo, $student_id) {
    // Get student total fees
    $stmt = $pdo->prepare("SELECT total_fees FROM students WHERE id = ?");
    $stmt->execute([$student_id]);
    $total_fees = (float) $stmt->fetchColumn();

    // Get payments total
    $payments_total = get_student_payments_total($pdo, $student_id);

    return $total_fees - $payments_total;
}

/**
 * Log user actions in the audit log
 */
function log_activity($pdo, $user_id, $action, $details = '') {
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_log (user_id, action, details) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $action, $details]);
    } catch (PDOException $e) {
        // Fail silently or handle error so main application flow is not disrupted
    }
}

/**
 * Checks if the student qualifies for automated clearance.
 * If balance <= 0, automatically creates/updates clearance to "Cleared".
 */
function auto_clearance_check($pdo, $student_id, $recorded_by) {
    $balance = get_student_balance($pdo, $student_id);
    
    // Get student details
    $stmt = $pdo->prepare("SELECT academic_year FROM students WHERE id = ?");
    $stmt->execute([$student_id]);
    $academic_year = $stmt->fetchColumn();
    
    if ($balance <= 0) {
        // Check if clearance record already exists
        $stmt = $pdo->prepare("SELECT id, status FROM clearances WHERE student_id = ? AND academic_year = ?");
        $stmt->execute([$student_id, $academic_year]);
        $clearance = $stmt->fetch();
        
        if ($clearance) {
            if ($clearance['status'] !== 'Cleared') {
                $upd = $pdo->prepare("UPDATE clearances SET status = 'Cleared', cleared_by = ?, cleared_at = CURRENT_TIMESTAMP, notes = 'Automated fee completion clearance' WHERE id = ?");
                $upd->execute([$recorded_by, $clearance['id']]);
                log_activity($pdo, $recorded_by, "Clearance Updated (Auto)", "Student ID: $student_id status set to Cleared");
            }
        } else {
            $ins = $pdo->prepare("INSERT INTO clearances (student_id, academic_year, semester, status, cleared_by, cleared_at, notes) VALUES (?, ?, 'Semester 1', 'Cleared', ?, CURRENT_TIMESTAMP, 'Automated fee completion clearance')");
            $ins->execute([$student_id, $academic_year, $recorded_by]);
            log_activity($pdo, $recorded_by, "Clearance Created (Auto)", "Student ID: $student_id status set to Cleared");
        }
    }
}

/**
 * Helper to display flash messages
 */
function display_flash_messages() {
    $html = '';
    if (isset($_SESSION['flash_success'])) {
        $html .= '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . htmlspecialchars($_SESSION['flash_success']) . '</div>';
        unset($_SESSION['flash_success']);
    }
    if (isset($_SESSION['flash_error'])) {
        $html .= '<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> ' . htmlspecialchars($_SESSION['flash_error']) . '</div>';
        unset($_SESSION['flash_error']);
    }
    if (isset($_SESSION['flash_info'])) {
        $html .= '<div class="alert alert-info"><i class="fas fa-info-circle"></i> ' . htmlspecialchars($_SESSION['flash_info']) . '</div>';
        unset($_SESSION['flash_info']);
    }
    return $html;
}
?>
