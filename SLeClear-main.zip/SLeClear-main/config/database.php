<?php
// config/database.php

define('DB_PATH', __DIR__ . '/../data/sleclear.db');

// Ensure data directory exists
if (!file_exists(dirname(DB_PATH))) {
    mkdir(dirname(DB_PATH), 0777, true);
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON;');
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Function to initialize database schema
function init_database($pdo) {
    // Users table
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT,
        role TEXT CHECK(role IN ('Admin','Finance','Registry')) NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );");

    // Students table
    $pdo->exec("CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id TEXT UNIQUE NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        department TEXT NOT NULL,
        faculty TEXT NOT NULL,
        level TEXT NOT NULL,
        academic_year TEXT NOT NULL,
        total_fees REAL NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );");

    // Payments table
    $pdo->exec("CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        payment_date DATE NOT NULL,
        payment_method TEXT CHECK(payment_method IN ('Cash','Bank Transfer','Mobile Money','Cheque')) NOT NULL,
        receipt_number TEXT,
        description TEXT,
        recorded_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY (recorded_by) REFERENCES users(id)
    );");

    // Clearances table
    $pdo->exec("CREATE TABLE IF NOT EXISTS clearances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        academic_year TEXT NOT NULL,
        semester TEXT NOT NULL,
        status TEXT CHECK(status IN ('Cleared','Pending','Provisional','Denied')) DEFAULT 'Pending',
        cleared_by INTEGER,
        cleared_at DATETIME,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY (cleared_by) REFERENCES users(id)
    );");

    // Deferred Assessments table
    $pdo->exec("CREATE TABLE IF NOT EXISTS deferred_assessments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        course_code TEXT NOT NULL,
        course_name TEXT NOT NULL,
        reason TEXT NOT NULL,
        fee_amount REAL NOT NULL DEFAULT 0,
        fee_paid INTEGER DEFAULT 0,
        status TEXT CHECK(status IN ('Pending','Approved','Denied')) DEFAULT 'Pending',
        document_path TEXT,
        submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        reviewed_by INTEGER,
        reviewed_at DATETIME,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY (reviewed_by) REFERENCES users(id)
    );");

    // Add column if it doesn't exist (backward compatibility)
    try {
        @$pdo->exec("ALTER TABLE deferred_assessments ADD COLUMN document_path TEXT;");
    } catch (PDOException $e) {
        // Column already exists, ignore
    }

    // Activity Log
    $pdo->exec("CREATE TABLE IF NOT EXISTS activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        details TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );");

    // Seed default users if table is empty
    $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($userCount == 0) {
        $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
        
        // Passwords: admin123, finance123, registry123
        $stmt->execute(['admin', password_hash('admin123', PASSWORD_BCRYPT), 'System Administrator', 'admin@usl.edu.sl', 'Admin']);
        $stmt->execute(['finance', password_hash('finance123', PASSWORD_BCRYPT), 'Finance Officer', 'finance@usl.edu.sl', 'Finance']);
        $stmt->execute(['registry', password_hash('registry123', PASSWORD_BCRYPT), 'Registry Clerk', 'registry@usl.edu.sl', 'Registry']);
    }


}

// Automatically initialize database on first require/include
init_database($pdo);
?>
