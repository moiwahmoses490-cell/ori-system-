<?php
// pages/payment_form.php
$page_title = "Record Fee Payment";
require_once __DIR__ . '/../includes/header.php';

// Authorization
require_role(['Admin', 'Finance']);

// Fetch list of students for selection dropdown
try {
    $stmt = $pdo->query("SELECT id, student_id, first_name, last_name, total_fees FROM students ORDER BY student_id ASC");
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load students dropdown: " . $e->getMessage() . "</div>";
    $students = [];
}
?>

<div class="card" style="max-width: 600px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-file-invoice-dollar"></i> Record Tuition Payment</h3>
        <div class="header-actions">
            <a href="/pages/payments.php" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-chevron-left"></i> Back to Payments
            </a>
        </div>
    </div>
    
    <form action="/api/payments.php" method="POST" class="payment-form">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <div class="form-group">
            <label for="student_id_select"><i class="fa-solid fa-user-graduate"></i> Select Student *</label>
            <select id="student_id_select" name="student_id" required>
                <option value="" disabled selected>-- Choose Student --</option>
                <?php foreach ($students as $student): ?>
                    <?php 
                    $balance = get_student_balance($pdo, $student['id']); 
                    ?>
                    <option value="<?php echo $student['id']; ?>" 
                            data-fees="<?php echo $student['total_fees']; ?>" 
                            data-balance="<?php echo $balance; ?>">
                        <?php echo htmlspecialchars($student['student_id'] . " - " . $student['first_name'] . " " . $student['last_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-grid">
            <div class="form-group">
                <label for="total_fees"><i class="fa-solid fa-money-check-dollar"></i> Total Fees Billed</label>
                <input type="text" id="total_fees" readonly value="0.00" 
                       style="background-color: rgba(255, 255, 255, 0.02); color: var(--text-muted); cursor: not-allowed;">
            </div>
            
            <div class="form-group">
                <label for="current_balance"><i class="fa-solid fa-scale-unbalanced"></i> Outstanding Balance</label>
                <input type="text" id="current_balance" readonly value="0.00" 
                       style="background-color: rgba(255, 255, 255, 0.02); color: var(--text-muted); cursor: not-allowed;">
            </div>
            
            <div class="form-group">
                <label for="amount"><i class="fa-solid fa-circle-dollar-to-slot"></i> Payment Amount *</label>
                <input type="number" step="0.01" min="0.01" id="amount" name="amount" placeholder="0.00" required>
            </div>
            
            <div class="form-group">
                <label for="payment_date"><i class="fa-solid fa-calendar-day"></i> Payment Date *</label>
                <input type="date" id="payment_date" name="payment_date" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="payment_method"><i class="fa-solid fa-wallet"></i> Payment Method *</label>
                <select id="payment_method" name="payment_method" required>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cash">Cash</option>
                    <option value="Mobile Money">Mobile Money</option>
                    <option value="Cheque">Cheque</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="receipt_number"><i class="fa-solid fa-barcode"></i> Receipt/Transaction ID</label>
                <input type="text" id="receipt_number" name="receipt_number" placeholder="e.g. REC-12345">
            </div>
        </div>
        
        <div class="form-group">
            <label for="description"><i class="fa-solid fa-comment-dots"></i> Payment Description / Notes</label>
            <textarea id="description" name="description" placeholder="e.g. First semester installment" rows="3"></textarea>
        </div>
        
        <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 10px;">
            <a href="/pages/payments.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-success">
                <i class="fa-solid fa-circle-check"></i> Record Payment
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
