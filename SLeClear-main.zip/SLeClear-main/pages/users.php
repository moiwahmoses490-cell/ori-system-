<?php
// pages/users.php
$page_title = "User Accounts Registry";
require_once __DIR__ . '/../includes/header.php';

// Authorization Check
require_role('Admin');

// Handle creating user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = trim($_POST['role'] ?? '');
    
    // CSRF Validation
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $_SESSION['flash_error'] = "Security validation failed. Please try again.";
        header("Location: /pages/users.php");
        exit;
    }
    
    if (empty($username) || empty($password) || empty($full_name) || empty($role)) {
        $_SESSION['flash_error'] = "All mandatory fields must be filled.";
    } else {
        try {
            // Check username uniqueness
            $chk = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
            $chk->execute([$username]);
            if ($chk->fetchColumn() > 0) {
                $_SESSION['flash_error'] = "Username '$username' is already taken.";
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$username, $hash, $full_name, $email, $role]);
                
                log_activity($pdo, $_SESSION['user_id'], 'Create User', "Created system user account '$username' with role '$role'");
                $_SESSION['flash_success'] = "User account '$username' created successfully.";
                // Refresh list
                header("Location: /pages/users.php");
                exit;
            }
        } catch (PDOException $e) {
            $_SESSION['flash_error'] = "Database error: " . $e->getMessage();
        }
    }
}

// Fetch user list
try {
    $stmt = $pdo->query("SELECT id, username, full_name, email, role, is_active, created_at FROM users ORDER BY id ASC");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load users: " . $e->getMessage() . "</div>";
    $users = [];
}
?>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
    <!-- Users Directory -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fa-solid fa-users-gear"></i> System Administrators & Officers</h3>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Staff Profile</th>
                        <th>Username</th>
                        <th>User Role</th>
                        <th>Created Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <?php 
                        $badge_class = 'badge-role-' . strtolower($user['role']);
                        ?>
                        <tr>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div class="avatar" style="width: 32px; height: 32px; font-size: 12px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--info)); display: flex; align-items: center; justify-content: center; font-weight: 700; color: white;">
                                        <?php echo strtoupper(substr($user['full_name'], 0, 2)); ?>
                                    </div>
                                    <div>
                                        <span style="display: block; font-weight: 600;"><?php echo htmlspecialchars($user['full_name']); ?></span>
                                        <span style="display: block; font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars($user['email'] ?: 'N/A'); ?></span>
                                    </div>
                                </div>
                            </td>
                            <td><code><?php echo htmlspecialchars($user['username']); ?></code></td>
                            <td><span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($user['role']); ?></span></td>
                            <td style="font-size: 12px; color: var(--text-secondary);"><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                            <td>
                                <span class="badge <?php echo $user['is_active'] ? 'badge-success' : 'badge-danger'; ?>">
                                    <?php echo $user['is_active'] ? 'Active' : 'Suspended'; ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- User Creation Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fa-solid fa-user-plus"></i> Add User Account</h3>
        </div>
        
        <form action="/pages/users.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <div class="form-group">
                <label for="full_name"><i class="fa-solid fa-signature"></i> Full Name *</label>
                <input type="text" id="full_name" name="full_name" placeholder="e.g. John Kamara" required>
            </div>
            
            <div class="form-group">
                <label for="email"><i class="fa-regular fa-envelope"></i> Email Address</label>
                <input type="email" id="email" name="email" placeholder="e.g. jkamara@usl.edu.sl">
            </div>
            
            <div class="form-group">
                <label for="username"><i class="fa-solid fa-user"></i> Username *</label>
                <input type="text" id="username" name="username" placeholder="Choose username" required>
            </div>
            
            <div class="form-group">
                <label for="password"><i class="fa-solid fa-lock"></i> Password *</label>
                <input type="password" id="password" name="password" placeholder="Create password" required>
            </div>
            
            <div class="form-group">
                <label for="role"><i class="fa-solid fa-users-gear"></i> System Role *</label>
                <select id="role" name="role" required>
                    <option value="" disabled selected>Select Access Role</option>
                    <option value="Admin">Admin</option>
                    <option value="Finance">Finance</option>
                    <option value="Registry">Registry</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block" style="margin-top: 10px;">
                <i class="fa-solid fa-circle-check"></i> Register Account
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
