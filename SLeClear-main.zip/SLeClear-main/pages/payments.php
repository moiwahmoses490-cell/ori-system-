<?php
// pages/payments.php
$page_title = "Fees Payment Transactions";
require_once __DIR__ . '/../includes/header.php';

// Authorization
require_role(['Admin', 'Finance']);

// Pagination settings
$per_page = 25;
$page = max(1, intval($_GET['page'] ?? 1));

// Fetch payment transactions with pagination
try {
    $total_count = $pdo->query("SELECT COUNT(*) FROM payments")->fetchColumn();
    $total_pages = max(1, (int) ceil($total_count / $per_page));
    $page = min($page, $total_pages);
    $offset = ($page - 1) * $per_page;

    $stmt = $pdo->prepare("SELECT p.*, s.student_id as student_id_text, s.first_name, s.last_name, u.full_name as recorded_by_name 
                         FROM payments p 
                         JOIN students s ON p.student_id = s.id 
                         JOIN users u ON p.recorded_by = u.id 
                         ORDER BY p.id DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $per_page, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $payments = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load payments list: " . $e->getMessage() . "</div>";
    $payments = [];
    $total_count = 0;
    $total_pages = 1;
}
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-receipt"></i> Payment Records</h3>
        <div class="header-actions">
            <a href="/pages/payment_form.php" class="btn btn-success btn-sm">
                <i class="fa-solid fa-plus-circle"></i> Record Fee Payment
            </a>
        </div>
    </div>
    
    <!-- Action Controls (Search & Filters) -->
    <div class="action-controls">
        <div class="search-box">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="table-search" placeholder="Search payments by student ID, name, receipt number...">
        </div>
        
        <div class="filter-group">
            <label for="filter-method"><i class="fa-solid fa-filter"></i> Method:</label>
            <select id="filter-method" class="table-filter" data-column="4">
                <option value="">All Methods</option>
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Mobile Money">Mobile Money</option>
                <option value="Cheque">Cheque</option>
            </select>
        </div>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Amount Paid</th>
                    <th>Payment Method</th>
                    <th>Receipt Number</th>
                    <th>Description</th>
                    <th>Recorded By</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($payments) > 0): ?>
                    <?php foreach ($payments as $payment): ?>
                        <tr>
                            <td><strong><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></strong></td>
                            <td><strong><?php echo htmlspecialchars($payment['student_id_text']); ?></strong></td>
                            <td><?php echo htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']); ?></td>
                            <td><strong class="text-success"><?php echo format_currency($payment['amount']); ?></strong></td>
                            <td><span class="badge badge-info"><?php echo htmlspecialchars($payment['payment_method']); ?></span></td>
                            <td><code><?php echo htmlspecialchars($payment['receipt_number'] ?: 'N/A'); ?></code></td>
                            <td style="font-size: 13px; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <?php echo htmlspecialchars($payment['description'] ?: 'N/A'); ?>
                            </td>
                            <td><?php echo htmlspecialchars($payment['recorded_by_name']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr class="no-results">
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            <i class="fa-solid fa-receipt" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                            No fee payments recorded yet.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination Controls -->
    <?php if ($total_pages > 1): ?>
    <div class="pagination-controls" style="display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-top: 1px solid var(--border-color); font-size: 13px; color: var(--text-secondary);">
        <span>Showing <?php echo $offset + 1; ?>–<?php echo min($offset + $per_page, $total_count); ?> of <?php echo $total_count; ?> payments</span>
        <div style="display: flex; gap: 8px; align-items: center;">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-chevron-left"></i> Prev</a>
            <?php endif; ?>
            <span style="padding: 4px 12px; background: rgba(255,255,255,0.05); border-radius: 6px; font-weight: 600;">Page <?php echo $page; ?> / <?php echo $total_pages; ?></span>
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>" class="btn btn-secondary btn-sm">Next <i class="fa-solid fa-chevron-right"></i></a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
