<?php
// pages/students.php
$page_title = "Students Management";
require_once __DIR__ . '/../includes/header.php';

// Authorization Check
require_role(['Admin', 'Registry']);

// Pagination settings
$per_page = 25;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $per_page;

// Fetch students list with pagination
try {
    $total_count = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $total_pages = max(1, (int) ceil($total_count / $per_page));
    $page = min($page, $total_pages); // clamp to valid range
    $offset = ($page - 1) * $per_page;
    
    $stmt = $pdo->prepare("SELECT * FROM students ORDER BY id DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $per_page, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load students list: " . $e->getMessage() . "</div>";
    $students = [];
    $total_count = 0;
    $total_pages = 1;
}
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-users"></i> Registered Students</h3>
        <div class="header-actions">
            <a href="/pages/student_form.php" class="btn btn-primary btn-sm">
                <i class="fa-solid fa-user-plus"></i> Register Student
            </a>
        </div>
    </div>
    
    <!-- Action Controls (Search & Filters) -->
    <div class="action-controls">
        <div class="search-box">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="table-search" placeholder="Search students by ID, name, email...">
        </div>
        
        <div class="filter-group">
            <label for="filter-dept"><i class="fa-solid fa-filter"></i> Dept:</label>
            <select id="filter-dept" class="table-filter" data-column="3">
                <option value="">All Departments</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Business Administration">Business Administration</option>
                <option value="Civil Engineering">Civil Engineering</option>
                <option value="Nursing">Nursing</option>
                <option value="Law">Law</option>
            </select>
        </div>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Full Name</th>
                    <th>Email / Phone</th>
                    <th>Department & Level</th>
                    <?php if (has_role('Admin')): ?>
                    <th>Total Fees</th>
                    <th>Fees Paid</th>
                    <th>Balance</th>
                    <?php endif; ?>
                    <th style="width: 150px; text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($students) > 0): ?>
                    <?php foreach ($students as $student): ?>
                        <?php 
                        $payments_total = get_student_payments_total($pdo, $student['id']);
                        $balance = get_student_balance($pdo, $student['id']);
                        $balance_class = $balance <= 0 ? 'text-success' : 'text-danger';
                        ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($student['student_id']); ?></strong></td>
                            <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                            <td style="font-size: 13px;">
                                <span style="display: block;"><i class="fa-regular fa-envelope"></i> <?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></span>
                                <span style="display: block; color: var(--text-muted);"><i class="fa-solid fa-phone"></i> <?php echo htmlspecialchars($student['phone'] ?? 'N/A'); ?></span>
                            </td>
                            <td>
                                <span style="display: block; font-weight: 500;"><?php echo htmlspecialchars($student['department']); ?></span>
                                <span style="display: block; font-size: 12px; color: var(--text-muted);"><?php echo htmlspecialchars($student['faculty']); ?> | Yr <?php echo htmlspecialchars($student['level']); ?></span>
                            </td>
                            <?php if (has_role('Admin')): ?>
                            <td><?php echo format_currency($student['total_fees']); ?></td>
                            <td><?php echo format_currency($payments_total); ?></td>
                            <td>
                                <strong class="<?php echo $balance_class; ?>">
                                    <?php echo format_currency($balance); ?>
                                </strong>
                            </td>
                            <?php endif; ?>
                            <td style="text-align: right;">
                                <div style="display: inline-flex; gap: 8px;">
                                    <a href="/pages/student_form.php?id=<?php echo $student['id']; ?>" class="btn btn-secondary btn-sm" title="Edit Student">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    
                                    <?php if (has_role('Admin')): ?>
                                        <a href="/api/students.php?action=delete&id=<?php echo $student['id']; ?>" 
                                           class="btn btn-danger btn-sm confirm-action" 
                                           data-confirm-message="Are you sure you want to delete student <?php echo htmlspecialchars($student['student_id']); ?>? This will delete all payments and clearance records." 
                                           title="Delete Student">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr class="no-results">
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            <i class="fa-solid fa-users" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                            No students registered yet.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination Controls -->
    <?php if ($total_pages > 1): ?>
    <div class="pagination-controls" style="display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-top: 1px solid var(--border-color); font-size: 13px; color: var(--text-secondary);">
        <span>Showing <?php echo $offset + 1; ?>–<?php echo min($offset + $per_page, $total_count); ?> of <?php echo $total_count; ?> students</span>
        <div style="display: flex; gap: 8px; align-items: center;">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-chevron-left"></i> Prev</a>
            <?php endif; ?>
            <span style="padding: 4px 12px; background: rgba(255,255,255,0.05); border-radius: 6px; font-weight: 600;">Page <?php echo $page; ?> / <?php echo $total_pages; ?></span>
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>" class="btn btn-secondary btn-sm">Next <i class="fa-solid fa-chevron-right"></i></a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
