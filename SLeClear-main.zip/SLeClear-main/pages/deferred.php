<?php
// pages/deferred.php
$page_title = "Deferred Assessments Workflows";
require_once __DIR__ . '/../includes/header.php';

// Fetch deferred applications
try {
    $stmt = $pdo->query("SELECT d.*, s.student_id as student_id_text, s.first_name, s.last_name, u.full_name as reviewer_name 
                         FROM deferred_assessments d 
                         JOIN students s ON d.student_id = s.id 
                         LEFT JOIN users u ON d.reviewed_by = u.id 
                         ORDER BY d.id DESC");
    $deferred = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load deferred applications: " . $e->getMessage() . "</div>";
    $deferred = [];
}
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-calendar-minus"></i> Deferred Exam Applications</h3>
        <div class="header-actions">
            <a href="/pages/deferred_form.php" class="btn btn-primary btn-sm">
                <i class="fa-solid fa-file-signature"></i> Apply for Deferral
            </a>
        </div>
    </div>
    
    <!-- Action Controls (Search & Filters) -->
    <div class="action-controls">
        <div class="search-box">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="table-search" placeholder="Search applications by student, course, reason...">
        </div>
        
        <div class="filter-group">
            <label for="filter-status"><i class="fa-solid fa-filter"></i> Status:</label>
            <select id="filter-status" class="table-filter" data-column="5">
                <option value="">All Statuses</option>
                <option value="Approved">Approved</option>
                <option value="Pending">Pending</option>
                <option value="Denied">Denied</option>
            </select>
        </div>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Course Code & Title</th>
                    <?php if (has_role(['Admin', 'Finance'])): ?>
                    <th>Fee (Le 150)</th>
                    <?php endif; ?>
                    <th>Reason / Details</th>
                    <th>Document</th>
                    <th>Status</th>
                    <th>Review / Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($deferred) > 0): ?>
                    <?php foreach ($deferred as $d): ?>
                        <?php 
                        $badge_class = '';
                        switch ($d['status']) {
                            case 'Approved': $badge_class = 'badge-success'; break;
                            case 'Pending': $badge_class = 'badge-warning'; break;
                            case 'Denied': $badge_class = 'badge-danger'; break;
                        }
                        
                        $paid_badge = $d['fee_paid'] ? 'badge-success' : 'badge-danger';
                        $paid_text = $d['fee_paid'] ? 'Paid' : 'Unpaid';
                        ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($d['student_id_text']); ?></strong></td>
                            <td><?php echo htmlspecialchars($d['first_name'] . ' ' . $d['last_name']); ?></td>
                            <td>
                                <span style="display: block; font-weight: 600; color: var(--primary);"><?php echo htmlspecialchars($d['course_code']); ?></span>
                                <span style="display: block; font-size: 12px; color: var(--text-secondary);"><?php echo htmlspecialchars($d['course_name']); ?></span>
                            </td>
                            <?php if (has_role(['Admin', 'Finance'])): ?>
                            <td>
                                <span class="badge <?php echo $paid_badge; ?>"><?php echo $paid_text; ?></span>
                            </td>
                            <?php endif; ?>
                            <td style="max-width: 200px; font-size: 13px;">
                                <span style="display: block; font-weight: 500;"><?php echo htmlspecialchars($d['reason']); ?></span>
                                <span style="display: block; font-size: 11px; color: var(--text-muted); margin-top: 2px;">Applied: <?php echo date('M d, Y', strtotime($d['submitted_at'])); ?></span>
                            </td>
                            <td style="text-align: center;">
                                <?php if (!empty($d['document_path'])): ?>
                                    <a href="/<?php echo htmlspecialchars($d['document_path']); ?>" target="_blank" class="btn btn-secondary btn-sm" title="View Attached Document" style="padding: 4px 8px; font-size: 11px;">
                                        <i class="fa-solid fa-paperclip"></i> View
                                    </a>
                                <?php else: ?>
                                    <span style="font-size: 11px; color: var(--text-muted);">None</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($d['status']); ?></span>
                            </td>
                            <td>
                                <?php if (has_role(['Admin', 'Finance'])): ?>
                                    <!-- Inline Review Action Form -->
                                    <form action="/api/deferred.php" method="POST" style="display: flex; gap: 8px; align-items: center;">
                                        <input type="hidden" name="action" value="review">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="id" value="<?php echo $d['id']; ?>">
                                        
                                        <select name="status" style="padding: 4px 8px; font-size: 12px; border-radius: 4px; background-color: rgba(0,0,0,0.2);">
                                            <option value="Pending" <?php echo $d['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="Approved" <?php echo $d['status'] === 'Approved' ? 'selected' : ''; ?>>Approved</option>
                                            <option value="Denied" <?php echo $d['status'] === 'Denied' ? 'selected' : ''; ?>>Denied</option>
                                        </select>
                                        
                                        <div style="display: flex; align-items: center; gap: 4px; font-size: 11px; color: var(--text-secondary);">
                                            <input type="checkbox" name="fee_paid" value="1" id="fee_paid_<?php echo $d['id']; ?>" <?php echo $d['fee_paid'] ? 'checked' : ''; ?> style="width: 14px; height: 14px; margin: 0;">
                                            <label for="fee_paid_<?php echo $d['id']; ?>" style="font-size: 11px; cursor: pointer;">Paid</label>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-primary btn-sm" style="padding: 4px 8px; font-size: 11px;">
                                            <i class="fa-solid fa-floppy-disk"></i>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <div style="font-size: 12px; color: var(--text-muted);">
                                        <?php if ($d['reviewer_name']): ?>
                                            Reviewed by: <?php echo htmlspecialchars($d['reviewer_name']); ?>
                                        <?php else: ?>
                                            Awaiting review
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr class="no-results">
                        <td colspan="<?php echo has_role(['Admin', 'Finance']) ? '8' : '7'; ?>" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            <i class="fa-solid fa-calendar-minus" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                            No deferred assessment applications found.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
