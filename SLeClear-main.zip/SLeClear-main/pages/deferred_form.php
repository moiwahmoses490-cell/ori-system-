<?php
// pages/deferred_form.php
$page_title = "Apply for Deferred Assessment";
require_once __DIR__ . '/../includes/header.php';

// Authorization: Admin, Finance, Registry
require_role(['Admin', 'Finance', 'Registry']);

// Fetch list of students
try {
    $stmt = $pdo->query("SELECT id, student_id, first_name, last_name FROM students ORDER BY student_id ASC");
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load students list: " . $e->getMessage() . "</div>";
    $students = [];
}
?>

<div class="card" style="max-width: 600px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-file-signature"></i> Deferral Application Form</h3>
        <div class="header-actions">
            <a href="/pages/deferred.php" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-chevron-left"></i> Back to List
            </a>
        </div>
    </div>
    
    <form action="/api/deferred.php" method="POST" enctype="multipart/form-data" class="deferred-form">
        <input type="hidden" name="action" value="submit">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        
        <div class="form-group">
            <label for="student_id"><i class="fa-solid fa-user-graduate"></i> Select Student *</label>
            <select id="student_id" name="student_id" required>
                <option value="" disabled selected>-- Choose Student --</option>
                <?php foreach ($students as $student): ?>
                    <option value="<?php echo $student['id']; ?>">
                        <?php echo htmlspecialchars($student['student_id'] . " - " . $student['first_name'] . " " . $student['last_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-grid">
            <div class="form-group">
                <label for="course_code"><i class="fa-solid fa-barcode"></i> Course Code *</label>
                <input type="text" id="course_code" name="course_code" placeholder="e.g. CS-401" required>
            </div>
            
            <div class="form-group">
                <label for="course_name"><i class="fa-solid fa-book"></i> Course Title *</label>
                <input type="text" id="course_name" name="course_name" placeholder="e.g. Artificial Intelligence" required>
            </div>
            
            <div class="form-group">
                <label for="fee_amount"><i class="fa-solid fa-coins"></i> Deferral Fee (Le)</label>
                <input type="number" id="fee_amount" name="fee_amount" value="150.00" readonly 
                       style="background-color: rgba(255, 255, 255, 0.02); color: var(--text-muted); cursor: not-allowed;">
            </div>
            
            <div class="form-group" style="justify-content: center;">
                <label for="fee_paid" style="margin-top: 24px; cursor: pointer; flex-direction: row; gap: 8px;">
                    <input type="checkbox" name="fee_paid" value="1" id="fee_paid" style="width: 18px; height: 18px;">
                    <span>Deferral Fee Paid?</span>
                </label>
            </div>
        </div>
        
        <div class="form-group">
            <label for="reason"><i class="fa-solid fa-comment-medical"></i> Reason for Deferral *</label>
            <textarea id="reason" name="reason" placeholder="State reasons: e.g. Illness (medical note attached), outstanding fees restricting main session exam..." rows="4" required></textarea>
        </div>
        
        <div class="form-group">
            <label for="supporting_doc"><i class="fa-solid fa-paperclip"></i> Supporting Document <span style="color: var(--text-muted); font-size: 12px;">(Medical cert., letter, etc.)</span></label>
            <input type="file" id="supporting_doc" name="supporting_doc" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                   style="padding: 8px; border: 1px dashed var(--border-color); border-radius: var(--radius-sm); cursor: pointer; width: 100%; color: var(--text-secondary);">
            <small style="color: var(--text-muted); font-size: 11px; margin-top: 4px; display: block;">Accepted: PDF, JPG, PNG, DOC (max 5MB)</small>
        </div>
        
        <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 10px;">
            <a href="/pages/deferred.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-paper-plane"></i> Submit Application
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
