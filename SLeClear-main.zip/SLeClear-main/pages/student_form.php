<?php
// pages/student_form.php
$id = isset($_GET['id']) ? intval($_GET['id']) : null;
$page_title = $id ? "Edit Student Information" : "Register New Student";

require_once __DIR__ . '/../includes/header.php';
require_role(['Admin', 'Registry']);

// Default values
$student = [
    'id' => '',
    'student_id' => '',
    'first_name' => '',
    'last_name' => '',
    'email' => '',
    'phone' => '',
    'department' => '',
    'faculty' => '',
    'level' => '100',
    'academic_year' => '2024/2025',
    'total_fees' => '0.00'
];

if ($id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->execute([$id]);
        $fetched = $stmt->fetch();
        if ($fetched) {
            $student = $fetched;
        } else {
            echo "<div class='alert alert-error'>Student record not found.</div>";
            $id = null; // revert to create mode
        }
    } catch (PDOException $e) {
        echo "<div class='alert alert-error'>Database error: " . $e->getMessage() . "</div>";
    }
}
?>

<div class="card" style="max-width: 800px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa-solid fa-user-edit"></i> 
            <?php echo $id ? "Update Profile details for " . htmlspecialchars($student['student_id']) : "Student Admissions Entry Form"; ?>
        </h3>
        <div class="header-actions">
            <a href="/pages/students.php" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-chevron-left"></i> Back to List
            </a>
        </div>
    </div>
    
    <form action="/api/students.php" method="POST" class="student-form">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <?php if ($id): ?>
            <input type="hidden" name="id" value="<?php echo $student['id']; ?>">
        <?php endif; ?>
        
        <div class="form-grid">
            <div class="form-group">
                <label for="student_id"><i class="fa-solid fa-id-card"></i> Student ID Number *</label>
                <input type="text" id="student_id" name="student_id" 
                       placeholder="e.g. USL/2024/0001" 
                       value="<?php echo htmlspecialchars($student['student_id']); ?>" 
                       required <?php echo $id ? 'readonly style="background-color: rgba(255,255,255,0.02); color: var(--text-muted); cursor: not-allowed;"' : ''; ?>>
            </div>
            
            <div class="form-group">
                <label for="academic_year"><i class="fa-solid fa-calendar"></i> Academic Year *</label>
                <input type="text" id="academic_year" name="academic_year" 
                       placeholder="e.g. 2024/2025" 
                       value="<?php echo htmlspecialchars($student['academic_year']); ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="first_name"><i class="fa-solid fa-user"></i> First Name *</label>
                <input type="text" id="first_name" name="first_name" 
                       placeholder="e.g. Mustapha" 
                       value="<?php echo htmlspecialchars($student['first_name']); ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="last_name"><i class="fa-solid fa-user"></i> Last Name *</label>
                <input type="text" id="last_name" name="last_name" 
                       placeholder="e.g. Kargbo" 
                       value="<?php echo htmlspecialchars($student['last_name']); ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="email"><i class="fa-regular fa-envelope"></i> Email Address</label>
                <input type="email" id="email" name="email" 
                       placeholder="e.g. mustapha@usl.edu.sl" 
                       value="<?php echo htmlspecialchars($student['email']); ?>">
            </div>
            
            <div class="form-group">
                <label for="phone"><i class="fa-solid fa-phone"></i> Phone Number</label>
                <input type="text" id="phone" name="phone" 
                       placeholder="e.g. +232 77 123456" 
                       value="<?php echo htmlspecialchars($student['phone']); ?>">
            </div>
            
            <div class="form-group">
                <label for="faculty"><i class="fa-solid fa-building-columns"></i> Faculty *</label>
                <select id="faculty" name="faculty" required>
                    <option value="" disabled selected>Select Faculty</option>
                    <option value="Faculty of Engineering & Technology" <?php echo $student['faculty'] === 'Faculty of Engineering & Technology' ? 'selected' : ''; ?>>Faculty of Engineering & Technology</option>
                    <option value="Faculty of Management Sciences" <?php echo $student['faculty'] === 'Faculty of Management Sciences' ? 'selected' : ''; ?>>Faculty of Management Sciences</option>
                    <option value="Faculty of Pure & Applied Sciences" <?php echo $student['faculty'] === 'Faculty of Pure & Applied Sciences' ? 'selected' : ''; ?>>Faculty of Pure & Applied Sciences</option>
                    <option value="Faculty of Social Sciences & Law" <?php echo $student['faculty'] === 'Faculty of Social Sciences & Law' ? 'selected' : ''; ?>>Faculty of Social Sciences & Law</option>
                </select>
            </div>

            <div class="form-group">
                <label for="department"><i class="fa-solid fa-brain"></i> Department *</label>
                <select id="department" name="department" required>
                    <option value="" disabled selected>Select Department</option>
                    <option value="Computer Science" <?php echo $student['department'] === 'Computer Science' ? 'selected' : ''; ?>>Computer Science</option>
                    <option value="Business Administration" <?php echo $student['department'] === 'Business Administration' ? 'selected' : ''; ?>>Business Administration</option>
                    <option value="Civil Engineering" <?php echo $student['department'] === 'Civil Engineering' ? 'selected' : ''; ?>>Civil Engineering</option>
                    <option value="Nursing" <?php echo $student['department'] === 'Nursing' ? 'selected' : ''; ?>>Nursing</option>
                    <option value="Law" <?php echo $student['department'] === 'Law' ? 'selected' : ''; ?>>Law</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="level"><i class="fa-solid fa-arrow-up-9-1"></i> Level / Year *</label>
                <select id="level" name="level" required>
                    <option value="100" <?php echo $student['level'] === '100' ? 'selected' : ''; ?>>100 (Year 1)</option>
                    <option value="200" <?php echo $student['level'] === '200' ? 'selected' : ''; ?>>200 (Year 2)</option>
                    <option value="300" <?php echo $student['level'] === '300' ? 'selected' : ''; ?>>300 (Year 3)</option>
                    <option value="400" <?php echo $student['level'] === '400' ? 'selected' : ''; ?>>400 (Year 4)</option>
                    <option value="500" <?php echo $student['level'] === '500' ? 'selected' : ''; ?>>500 (Year 5)</option>
                    <option value="Postgraduate" <?php echo $student['level'] === 'Postgraduate' ? 'selected' : ''; ?>>Postgraduate</option>
                </select>
            </div>

            <?php if (has_role('Admin')): ?>
            <div class="form-group">
                <label for="total_fees"><i class="fa-solid fa-money-bill-wave"></i> Total Academic Billed Fees *</label>
                <input type="number" step="0.01" min="0" id="total_fees" name="total_fees" 
                       placeholder="e.g. 15000.00" 
                       value="<?php echo htmlspecialchars($student['total_fees']); ?>" 
                       required>
            </div>
            <?php else: ?>
                <input type="hidden" name="total_fees" value="<?php echo htmlspecialchars($student['total_fees'] ?: '0.00'); ?>">
            <?php endif; ?>
        </div>
        
        <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 10px;">
            <a href="/pages/students.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-save"></i> <?php echo $id ? "Save Changes" : "Register Student"; ?>
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
