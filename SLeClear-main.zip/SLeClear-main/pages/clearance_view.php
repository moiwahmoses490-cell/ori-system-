<?php
// pages/clearance_view.php
$page_title = "Clearance Certificate Slip";
require_once __DIR__ . '/../includes/header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : null;

if (!$id) {
    echo "<div class='alert alert-error'>No clearance record specified.</div>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT c.id as clearance_id, c.academic_year as cl_year, c.semester as cl_semester, c.status as cl_status, c.notes as cl_notes, c.cleared_at,
                                 s.id as student_id, s.student_id as student_id_text, s.first_name, s.last_name, s.department, s.faculty, s.level, s.email, s.phone,
                                 u.full_name as officer_name
                          FROM clearances c 
                          JOIN students s ON c.student_id = s.id 
                          LEFT JOIN users u ON c.cleared_by = u.id
                          WHERE c.id = ?");
    $stmt->execute([$id]);
    $c = $stmt->fetch();
    
    if (!$c) {
        echo "<div class='alert alert-error'>Clearance record not found.</div>";
        require_once __DIR__ . '/../includes/footer.php';
        exit;
    }
    
    $balance = get_student_balance($pdo, $c['student_id']);
    
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Database error: " . $e->getMessage() . "</div>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}
?>

<div class="no-print" style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
    <a href="/pages/clearances.php" class="btn btn-secondary">
        <i class="fa-solid fa-chevron-left"></i> Back to Registries
    </a>
    
    <button onclick="printSlip()" class="btn btn-success">
        <i class="fa-solid fa-print"></i> Print Clearance Slip
    </button>
</div>

<!-- Print-Friendly Clearance Slip Container -->
<div class="card print-slip-container" style="background-color: white; color: #1e293b; max-width: 700px; margin: 0 auto; padding: 40px; border: 2px solid #e2e8f0; border-radius: var(--radius-md); position: relative; box-shadow: 0 4px 20px rgba(0,0,0,0.05);">
    
    <!-- Watermark Background -->
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-30deg); font-size: 80px; font-weight: 800; color: rgba(16, 185, 129, 0.04); pointer-events: none; text-transform: uppercase; white-space: nowrap; user-select: none;">
        <?php echo htmlspecialchars($c['cl_status']); ?>
    </div>
    
    <!-- Slip Header -->
    <div style="text-align: center; border-bottom: 3px double #1e293b; padding-bottom: 20px; margin-bottom: 30px;">
        <div style="font-size: 24px; font-family: var(--font-heading); font-weight: 800; color: #0f172a; text-transform: uppercase; letter-spacing: 1px;">
            University of Sierra Leone
        </div>
        <div style="font-size: 13px; font-weight: 600; color: #64748b; letter-spacing: 0.5px; text-transform: uppercase;">
            Office of the Registrar & Finance Division
        </div>
        <div style="font-size: 16px; font-weight: 700; color: #10b981; margin-top: 10px; text-transform: uppercase; letter-spacing: 2px;">
            Official Student Clearance Slip
        </div>
    </div>
    
    <!-- Slip Meta Grid -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; font-size: 14px;">
        <div>
            <span style="color: #64748b; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block;">Student Name</span>
            <strong style="color: #0f172a; font-size: 16px;"><?php echo htmlspecialchars($c['first_name'] . ' ' . $c['last_name']); ?></strong>
        </div>
        
        <div style="text-align: right;">
            <span style="color: #64748b; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block;">Student ID / Registration</span>
            <strong style="color: #0f172a; font-size: 16px;"><?php echo htmlspecialchars($c['student_id_text']); ?></strong>
        </div>
        
        <div>
            <span style="color: #64748b; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block;">Faculty / College</span>
            <span style="color: #334155; font-weight: 500;"><?php echo htmlspecialchars($c['faculty']); ?></span>
        </div>
        
        <div style="text-align: right;">
            <span style="color: #64748b; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block;">Department & Level</span>
            <span style="color: #334155; font-weight: 500;"><?php echo htmlspecialchars($c['department']); ?> | Yr <?php echo htmlspecialchars($c['level']); ?></span>
        </div>
        
        <div>
            <span style="color: #64748b; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block;">Academic Session</span>
            <span style="color: #334155; font-weight: 500;"><?php echo htmlspecialchars($c['cl_year'] . ' - ' . $c['cl_semester']); ?></span>
        </div>
        
        <div style="text-align: right;">
            <span style="color: #64748b; font-size: 11px; text-transform: uppercase; font-weight: 700; display: block;">System Slip Verification ID</span>
            <code style="background-color: #f1f5f9; padding: 2px 6px; border-radius: 4px; color: #0f172a; font-weight: 600; font-size: 12px;">SLE-<?php echo str_pad($c['clearance_id'], 6, '0', STR_PAD_LEFT); ?></code>
        </div>
    </div>
    
    <!-- Clearance Ledger Details -->
    <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 30px;">
        <h4 style="font-family: var(--font-heading); color: #0f172a; font-size: 14px; margin-bottom: 12px; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; text-transform: uppercase;">
            Financial Ledger Status
        </h4>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 13px;">
            <div style="color: #64748b;">Total Billed Tuition Fees:</div>
            <div style="text-align: right; font-weight: 600; color: #0f172a;"><?php echo format_currency($c['total_fees']); ?></div>
            
            <div style="color: #64748b;">Total Confirmed Payments:</div>
            <div style="text-align: right; font-weight: 600; color: #10b981;"><?php echo format_currency($c['total_fees'] - $balance); ?></div>
            
            <div style="color: #64748b; font-weight: 600;">Outstanding Ledger Balance:</div>
            <div style="text-align: right; font-weight: 700; color: <?php echo $balance > 0 ? '#ef4444' : '#10b981'; ?>;">
                <?php echo format_currency($balance); ?>
            </div>
        </div>
    </div>
    
    <!-- Status Declaration Badge -->
    <div style="text-align: center; margin-bottom: 40px;">
        <span style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #64748b; display: block; margin-bottom: 6px;">Current Compliance Status</span>
        <div style="display: inline-block; padding: 8px 24px; border-radius: 30px; font-size: 16px; font-weight: 800; text-transform: uppercase; border: 2px solid;
            <?php
            switch($c['cl_status']) {
                case 'Cleared': echo 'background-color: #ecfdf5; color: #047857; border-color: #059669;'; break;
                case 'Pending': echo 'background-color: #fffbeb; color: #b45309; border-color: #d97706;'; break;
                case 'Provisional': echo 'background-color: #f0f9ff; color: #0369a1; border-color: #0284c7;'; break;
                case 'Denied': echo 'background-color: #fef2f2; color: #b91c1c; border-color: #dc2626;'; break;
            }
            ?>">
            <i class="fa-solid <?php 
                switch($c['cl_status']) {
                    case 'Cleared': echo 'fa-circle-check'; break;
                    case 'Pending': echo 'fa-clock'; break;
                    case 'Provisional': echo 'fa-clock-rotate-left'; break;
                    case 'Denied': echo 'fa-circle-xmark'; break;
                }
            ?>"></i>
            <?php echo htmlspecialchars($c['cl_status']); ?>
        </div>
        <?php if ($c['cl_notes']): ?>
            <p style="font-size: 13px; font-style: italic; color: #475569; margin-top: 10px; max-width: 500px; margin-left: auto; margin-right: auto;">
                "<?php echo htmlspecialchars($c['cl_notes']); ?>"
            </p>
        <?php endif; ?>
    </div>
    
    <!-- Verification Box -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px; border-top: 1px dashed #cbd5e1; padding-top: 30px; font-size: 12px; color: #475569;">
        <div>
            <span style="display: block; font-weight: 700; text-transform: uppercase; font-size: 10px; color: #64748b;">Authorized Official</span>
            <span style="display: block; font-weight: 600; color: #0f172a; margin-top: 2px;"><?php echo htmlspecialchars($c['officer_name'] ?? 'System Process'); ?></span>
            <span style="display: block; font-size: 11px;">Verification Date: <?php echo $c['cleared_at'] ? date('M d, Y h:i A', strtotime($c['cleared_at'])) : date('M d, Y'); ?></span>
        </div>
        
        <div style="text-align: right; display: flex; flex-direction: column; align-items: flex-end; justify-content: flex-end;">
            <div style="width: 150px; border-bottom: 1px solid #475569; margin-bottom: 4px; height: 30px;"></div>
            <span style="font-weight: 700; text-transform: uppercase; font-size: 10px; color: #64748b;">Signature & Official Stamp</span>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
