<?php
// pages/clearances.php
$page_title = "Clearance Compliance Management";
require_once __DIR__ . '/../includes/header.php';

// Fetch clearances
try {
    $stmt = $pdo->query("SELECT c.id as clearance_id, c.academic_year as cl_year, c.semester as cl_semester, c.status as cl_status, c.notes as cl_notes, 
                                s.id as student_id, s.student_id as student_id_text, s.first_name, s.last_name, s.department, s.level 
                         FROM clearances c 
                         JOIN students s ON c.student_id = s.id 
                         ORDER BY c.id DESC");
    $clearances = $stmt->fetchAll();
    
    // Also fetch students who DO NOT have a clearance record yet, so we can display them as "Pending" (implicitly)
    $stmt2 = $pdo->query("SELECT s.id as student_id, s.student_id as student_id_text, s.first_name, s.last_name, s.department, s.level, s.academic_year 
                          FROM students s 
                          WHERE s.id NOT IN (SELECT student_id FROM clearances)");
    $unclearances = $stmt2->fetchAll();
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load clearances list: " . $e->getMessage() . "</div>";
    $clearances = [];
    $unclearances = [];
}
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-file-signature"></i> Student Clearance Registries</h3>
    </div>
    
    <!-- Action Controls (Search & Filters) -->
    <div class="action-controls">
        <div class="search-box">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="table-search" placeholder="Search clearances by student ID, name, status, notes...">
        </div>
        
        <div class="filter-group">
            <label for="filter-status"><i class="fa-solid fa-filter"></i> Status:</label>
            <select id="filter-status" class="table-filter" data-column="4">
                <option value="">All Statuses</option>
                <option value="Cleared">Cleared</option>
                <option value="Pending">Pending</option>
                <option value="Provisional">Provisional</option>
                <option value="Denied">Denied</option>
            </select>
        </div>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Dept & Level</th>
                    <th>Academic Year</th>
                    <th>Clearance Status</th>
                    <th>Notes / Override Status</th>
                    <th style="width: 150px; text-align: right;">Clearance Slip</th>
                </tr>
            </thead>
            <tbody>
                <!-- Explicit Clearance Records -->
                <?php foreach ($clearances as $c): ?>
                    <?php 
                    $balance = get_student_balance($pdo, $c['student_id']);
                    $badge_class = '';
                    switch ($c['cl_status']) {
                        case 'Cleared': $badge_class = 'badge-success'; break;
                        case 'Pending': $badge_class = 'badge-warning'; break;
                        case 'Provisional': $badge_class = 'badge-info'; break;
                        case 'Denied': $badge_class = 'badge-danger'; break;
                    }
                    ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($c['student_id_text']); ?></strong></td>
                        <td><?php echo htmlspecialchars($c['first_name'] . ' ' . $c['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($c['department']); ?> (Yr <?php echo htmlspecialchars($c['level']); ?>)</td>
                        <td><?php echo htmlspecialchars($c['cl_year'] . ' - ' . $c['cl_semester']); ?></td>
                        <td><span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($c['cl_status']); ?></span></td>
                        
                        <td>
                            <?php if (has_role(['Admin', 'Finance'])): ?>
                                <!-- Inline Override Form -->
                                <form action="/api/clearances.php" method="POST" style="display: flex; gap: 8px; align-items: center;">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="clearance_id" value="<?php echo $c['clearance_id']; ?>">
                                    <input type="hidden" name="student_id" value="<?php echo $c['student_id']; ?>">
                                    <input type="hidden" name="academic_year" value="<?php echo $c['cl_year']; ?>">
                                    <input type="hidden" name="semester" value="<?php echo $c['cl_semester']; ?>">
                                    
                                    <select name="status" style="padding: 4px 8px; font-size: 12px; border-radius: 4px; background-color: rgba(0,0,0,0.2);">
                                        <option value="Cleared" <?php echo $c['cl_status'] === 'Cleared' ? 'selected' : ''; ?>>Cleared</option>
                                        <option value="Pending" <?php echo $c['cl_status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="Provisional" <?php echo $c['cl_status'] === 'Provisional' ? 'selected' : ''; ?>>Provisional</option>
                                        <option value="Denied" <?php echo $c['cl_status'] === 'Denied' ? 'selected' : ''; ?>>Denied</option>
                                    </select>
                                    
                                    <input type="text" name="notes" placeholder="Reason..." 
                                           value="<?php echo htmlspecialchars($c['cl_notes'] ?: ''); ?>" 
                                           style="padding: 4px 8px; font-size: 12px; border-radius: 4px; background-color: rgba(0,0,0,0.2); width: 120px;">
                                    
                                    <button type="submit" class="btn btn-primary btn-sm" style="padding: 4px 8px; font-size: 11px;">
                                        <i class="fa-solid fa-floppy-disk"></i>
                                    </button>
                                </form>
                            <?php else: ?>
                                <span style="font-size: 13px; color: var(--text-secondary);"><?php echo htmlspecialchars($c['cl_notes'] ?: 'N/A'); ?></span>
                            <?php endif; ?>
                        </td>
                        
                        <td style="text-align: right;">
                            <a href="/pages/clearance_view.php?id=<?php echo $c['clearance_id']; ?>" class="btn btn-secondary btn-sm">
                                <i class="fa-solid fa-print"></i> Slip
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                
                <!-- Students with no clearance records yet (Implicitly Pending) -->
                <?php foreach ($unclearances as $u): ?>
                    <?php 
                    $balance = get_student_balance($pdo, $u['student_id']);
                    ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($u['student_id_text']); ?></strong></td>
                        <td><?php echo htmlspecialchars($u['first_name'] . ' ' . $u['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($u['department']); ?> (Yr <?php echo htmlspecialchars($u['level']); ?>)</td>
                        <td><?php echo htmlspecialchars($u['academic_year'] . ' - Semester 1'); ?></td>
                        <td><span class="badge badge-warning">Pending</span></td>
                        
                        <td>
                            <?php if (has_role(['Admin', 'Finance'])): ?>
                                <!-- Setup Clearance Override Form -->
                                <form action="/api/clearances.php" method="POST" style="display: flex; gap: 8px; align-items: center;">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="student_id" value="<?php echo $u['student_id']; ?>">
                                    <input type="hidden" name="academic_year" value="<?php echo $u['academic_year']; ?>">
                                    <input type="hidden" name="semester" value="Semester 1">
                                    
                                    <select name="status" style="padding: 4px 8px; font-size: 12px; border-radius: 4px; background-color: rgba(0,0,0,0.2);">
                                        <option value="Cleared">Cleared</option>
                                        <option value="Pending" selected>Pending</option>
                                        <option value="Provisional">Provisional</option>
                                        <option value="Denied">Denied</option>
                                    </select>
                                    
                                    <input type="text" name="notes" placeholder="Notes..." 
                                           style="padding: 4px 8px; font-size: 12px; border-radius: 4px; background-color: rgba(0,0,0,0.2); width: 120px;">
                                    
                                    <button type="submit" class="btn btn-primary btn-sm" style="padding: 4px 8px; font-size: 11px;">
                                        <i class="fa-solid fa-plus"></i> Set
                                    </button>
                                </form>
                            <?php else: ?>
                                <span style="font-size: 13px; color: var(--text-muted);">
                                    Uninitialized<?php echo has_role(['Admin', 'Finance']) ? '. Balance: ' . format_currency($balance) : ''; ?>
                                </span>
                            <?php endif; ?>
                        </td>
                        
                        <td style="text-align: right;">
                            <span style="font-size: 12px; color: var(--text-muted); font-style: italic;">Not Cleared</span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
