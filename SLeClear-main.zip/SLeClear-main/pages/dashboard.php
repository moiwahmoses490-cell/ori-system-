<?php
// pages/dashboard.php
$page_title = "Dashboard";
require_once __DIR__ . '/../includes/header.php';

// Calculate core metrics from database
try {
    // 1. Total Students
    $total_students = (int) $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
    
    // 2. Total Fees Billed
    $total_billed = (float) $pdo->query("SELECT SUM(total_fees) FROM students")->fetchColumn();
    
    // 3. Total Fees Paid
    $total_paid = (float) $pdo->query("SELECT SUM(amount) FROM payments")->fetchColumn();
    
    // 4. Total Outstanding Balance
    $total_outstanding = $total_billed - $total_paid;
    if ($total_outstanding < 0) $total_outstanding = 0;
    
    // 5. Clearance Statistics
    $cleared_count = (int) $pdo->query("SELECT COUNT(*) FROM clearances WHERE status = 'Cleared'")->fetchColumn();
    $pending_count = (int) $pdo->query("SELECT COUNT(*) FROM clearances WHERE status = 'Pending'")->fetchColumn();
    $provisional_count = (int) $pdo->query("SELECT COUNT(*) FROM clearances WHERE status = 'Provisional'")->fetchColumn();
    $denied_count = (int) $pdo->query("SELECT COUNT(*) FROM clearances WHERE status = 'Denied'")->fetchColumn();
    
    $clearance_percentage = $total_students > 0 ? round(($cleared_count / $total_students) * 100, 1) : 0;
    
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load dashboard metrics: " . $e->getMessage() . "</div>";
    $total_students = 0;
    $total_billed = 0;
    $total_paid = 0;
    $total_outstanding = 0;
    $cleared_count = 0;
    $pending_count = 0;
    $provisional_count = 0;
    $denied_count = 0;
    $clearance_percentage = 0;
}
?>

<!-- Metrics Overview Grid -->
<div class="metrics-grid">
    <div class="metric-card primary">
        <div class="metric-info">
            <h4>Total Students</h4>
            <div class="metric-value"><?php echo number_format($total_students); ?></div>
        </div>
        <div class="metric-icon">
            <i class="fa-solid fa-user-graduate"></i>
        </div>
    </div>
    
    <?php if (has_role(['Admin', 'Finance'])): ?>
    <div class="metric-card success">
        <div class="metric-info">
            <h4>Total Fees Collected</h4>
            <div class="metric-value"><?php echo format_currency($total_paid); ?></div>
        </div>
        <div class="metric-icon">
            <i class="fa-solid fa-wallet"></i>
        </div>
    </div>
    
    <div class="metric-card danger">
        <div class="metric-info">
            <h4>Outstanding Fees</h4>
            <div class="metric-value"><?php echo format_currency($total_outstanding); ?></div>
        </div>
        <div class="metric-icon">
            <i class="fa-solid fa-sack-xmark"></i>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="metric-card warning">
        <div class="metric-info">
            <h4>Overall Clearance Rate</h4>
            <div class="metric-value"><?php echo $clearance_percentage; ?>%</div>
        </div>
        <div class="metric-icon">
            <i class="fa-solid fa-circle-check"></i>
        </div>
    </div>
</div>

<!-- Dashboard Grid (Charts and Actions) -->
<div class="dashboard-grid" <?php echo !has_role(['Admin', 'Finance']) ? 'style="grid-template-columns: 1fr;"' : ''; ?>>
    <!-- Charts Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fa-solid fa-chart-column"></i> <?php echo has_role(['Admin', 'Finance']) ? 'System Financial & Compliance Visualizations' : 'System Compliance Visualizations'; ?></h3>
        </div>
        <div style="display: grid; grid-template-columns: <?php echo has_role(['Admin', 'Finance']) ? '1fr 1fr' : '1fr'; ?>; gap: 30px;">
            <?php if (has_role(['Admin', 'Finance'])): ?>
            <div style="height: 280px; position: relative;">
                <h4 style="font-size: 13px; text-align: center; margin-bottom: 10px; color: var(--text-secondary);">Fee Payment Status</h4>
                <canvas id="paymentChart"></canvas>
            </div>
            <?php endif; ?>
            <div style="height: 280px; position: relative;">
                <h4 style="font-size: 13px; text-align: center; margin-bottom: 10px; color: var(--text-secondary);">Student Clearances Distributions</h4>
                <canvas id="clearanceChart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Alerts & Tasks -->
    <?php if (has_role(['Admin', 'Finance'])): ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fa-solid fa-bell"></i> System Alerts</h3>
        </div>
        <div class="alerts-list" style="display: flex; flex-direction: column; gap: 12px;">
            <?php
            // Find students with low outstanding balances (potential provisional clearance candidates)
            try {
                $low_bal_stmt = $pdo->query("SELECT s.id, s.student_id, s.first_name, s.last_name, s.total_fees 
                                            FROM students s 
                                            LEFT JOIN clearances c ON s.id = c.student_id 
                                            WHERE c.status IS NULL OR c.status = 'Pending'");
                
                $alerts_triggered = 0;
                while ($student = $low_bal_stmt->fetch()) {
                    $bal = get_student_balance($pdo, $student['id']);
                    // If balance is low but positive, show alert
                    if ($bal > 0 && $bal <= 1500) {
                        echo '<div class="alert alert-warning" style="padding: 10px 14px; margin-bottom: 0; font-size: 13px;">
                            <div>
                                <i class="fa-solid fa-circle-exclamation"></i>
                                <strong>Provisional Candidate:</strong> ' . htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) . ' (' . $student['student_id'] . ') has low balance of <strong>' . format_currency($bal) . '</strong>.
                            </div>
                        </div>';
                        $alerts_triggered++;
                    }
                    if ($alerts_triggered >= 3) break; // cap at 3
                }
                
                // Show if no alerts triggered
                if ($alerts_triggered === 0) {
                    echo '<p style="color: var(--text-muted); font-size: 13px; text-align: center; padding: 20px 0;">
                        <i class="fa-solid fa-circle-check" style="color: var(--success); font-size: 18px; margin-bottom: 8px; display: block;"></i>
                        No critical clearance alerts at this time.
                    </p>';
                }
            } catch (PDOException $e) {
                // handle silently
            }
            ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php if (has_role(['Admin', 'Finance'])): ?>
<div class="card" style="margin-top: 24px;">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-clock-rotate-left"></i> Recent Activity Log</h3>
        <?php if (has_role('Admin')): ?>
            <span class="badge badge-info">System Audit Active</span>
        <?php endif; ?>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>User</th>
                    <th>Role</th>
                    <th>Action</th>
                    <th>Details</th>
                    <th>Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php
                try {
                    $log_stmt = $pdo->query("SELECT l.action, l.details, l.created_at, u.full_name, u.role 
                                            FROM activity_log l 
                                            LEFT JOIN users u ON l.user_id = u.id 
                                            ORDER BY l.id DESC LIMIT 5");
                    $rows = $log_stmt->fetchAll();
                    if (count($rows) > 0) {
                        foreach ($rows as $row) {
                            $badge_class = 'badge-role-' . strtolower($row['role'] ?? 'system');
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($row['full_name'] ?? 'System Process') . '</td>';
                            echo '<td><span class="badge ' . $badge_class . '">' . htmlspecialchars($row['role'] ?? 'System') . '</span></td>';
                            echo '<td><strong>' . htmlspecialchars($row['action']) . '</strong></td>';
                            echo '<td>' . htmlspecialchars($row['details']) . '</td>';
                            echo '<td>' . date('M d, Y h:i A', strtotime($row['created_at'])) . '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="5" style="text-align: center; color: var(--text-muted);">No activity recorded yet.</td></tr>';
                    }
                } catch (PDOException $e) {
                    echo '<tr><td colspan="5" style="color: var(--danger);">Error loading logs: ' . $e->getMessage() . '</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Render Charts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. Fee Payments Chart (Doughnut)
    <?php if (has_role(['Admin', 'Finance'])): ?>
    const ctxPayment = document.getElementById('paymentChart').getContext('2d');
    new Chart(ctxPayment, {
        type: 'doughnut',
        data: {
            labels: ['Fees Collected', 'Outstanding Fees'],
            datasets: [{
                data: [<?php echo $total_paid; ?>, <?php echo $total_outstanding; ?>],
                backgroundColor: ['#10b981', '#ef4444'],
                borderColor: '#1e293b',
                borderWidth: 2,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#94a3b8', font: { family: 'Inter', size: 12 } }
                }
            }
        }
    });
    <?php endif; ?>

    // 2. Clearance Status Chart (Bar)
    const ctxClearance = document.getElementById('clearanceChart').getContext('2d');
    new Chart(ctxClearance, {
        type: 'bar',
        data: {
            labels: ['Cleared', 'Pending', 'Provisional', 'Denied'],
            datasets: [{
                label: 'Students Count',
                data: [<?php echo $cleared_count; ?>, <?php echo $pending_count; ?>, <?php echo $provisional_count; ?>, <?php echo $denied_count; ?>],
                backgroundColor: ['#10b981', '#6366f1', '#f59e0b', '#ef4444'],
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: { grid: { display: false }, ticks: { color: '#94a3b8' } },
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#94a3b8', stepSize: 1 } }
            }
        }
    });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
