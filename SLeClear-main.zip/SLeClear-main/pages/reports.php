<?php
// pages/reports.php
$page_title = "Management Reports & Analytics";
require_once __DIR__ . '/../includes/header.php';

// Authorization Check
require_role(['Admin', 'Finance']);

// Fetch basic analytics for reports
try {
    $total_students = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $total_payments = $pdo->query("SELECT COUNT(*) FROM payments")->fetchColumn();
    $total_clearances = $pdo->query("SELECT COUNT(*) FROM clearances")->fetchColumn();
    
    // Top outstanding balances
    $balance_stmt = $pdo->query("SELECT id, student_id, first_name, last_name, total_fees FROM students ORDER BY total_fees DESC LIMIT 5");
    $top_balances = [];
    while ($row = $balance_stmt->fetch()) {
        $bal = get_student_balance($pdo, $row['id']);
        if ($bal > 0) {
            $row['balance'] = $bal;
            $top_balances[] = $row;
        }
    }
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load analytics: " . $e->getMessage() . "</div>";
    $top_balances = [];
}
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-file-export"></i> Data Exports</h3>
        <span class="badge badge-success"><i class="fa-solid fa-cloud-arrow-down"></i> CSV Export Ready</span>
    </div>
    <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 14px;">
        Generate and download spreadsheet summaries for administrative records, audits, and decision support.
    </p>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
        <!-- Students List Export -->
        <div style="background-color: rgba(15, 23, 42, 0.4); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 20px; display: flex; flex-direction: column; gap: 12px; justify-content: space-between;">
            <div>
                <h4 style="font-family: var(--font-heading); font-size: 16px; font-weight: 700; color: white;">
                    <i class="fa-solid fa-user-graduate" style="color: var(--primary); margin-right: 8px;"></i>
                    Students Master Registry
                </h4>
                <p style="font-size: 12px; color: var(--text-muted); margin-top: 6px;">
                    Contains complete list of registered students, department info, level, academic year, and outstanding tuition balances.
                </p>
                <span class="badge badge-info" style="margin-top: 10px;"><?php echo $total_students; ?> records</span>
            </div>
            <a href="/api/export.php?type=csv&report=students" class="btn btn-primary btn-sm btn-block">
                <i class="fa-solid fa-download"></i> Export CSV
            </a>
        </div>
        
        <!-- Payments Ledger Export -->
        <div style="background-color: rgba(15, 23, 42, 0.4); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 20px; display: flex; flex-direction: column; gap: 12px; justify-content: space-between;">
            <div>
                <h4 style="font-family: var(--font-heading); font-size: 16px; font-weight: 700; color: white;">
                    <i class="fa-solid fa-cash-register" style="color: var(--success); margin-right: 8px;"></i>
                    Payments Ledger
                </h4>
                <p style="font-size: 12px; color: var(--text-muted); margin-top: 6px;">
                    Contains full details of payments, transaction receipts, timestamps, payment methods, and recording officers.
                </p>
                <span class="badge badge-success" style="margin-top: 10px;"><?php echo $total_payments; ?> transactions</span>
            </div>
            <a href="/api/export.php?type=csv&report=payments" class="btn btn-success btn-sm btn-block">
                <i class="fa-solid fa-download"></i> Export CSV
            </a>
        </div>
        
        <!-- Clearance Status Export -->
        <div style="background-color: rgba(15, 23, 42, 0.4); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 20px; display: flex; flex-direction: column; gap: 12px; justify-content: space-between;">
            <div>
                <h4 style="font-family: var(--font-heading); font-size: 16px; font-weight: 700; color: white;">
                    <i class="fa-solid fa-shield-halved" style="color: var(--warning); margin-right: 8px;"></i>
                    Clearance Registries
                </h4>
                <p style="font-size: 12px; color: var(--text-muted); margin-top: 6px;">
                    Contains student clearance compliance listings, semesters, status (Cleared, Provisional, Denied), and compliance remarks.
                </p>
                <span class="badge badge-warning" style="margin-top: 10px;"><?php echo $total_clearances; ?> compliance listings</span>
            </div>
            <a href="/api/export.php?type=csv&report=clearances" class="btn btn-warning btn-sm btn-block">
                <i class="fa-solid fa-download"></i> Export CSV
            </a>
        </div>
    </div>
</div>

<div class="card" style="margin-top: 24px;">
    <div class="card-header">
        <h3 class="card-title"><i class="fa-solid fa-triangle-exclamation"></i> Outstandings Audit: Top Debtors</h3>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Total Tuition Billed</th>
                    <th>Total Payments</th>
                    <th>Outstanding Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($top_balances) > 0): ?>
                    <?php foreach ($top_balances as $tb): ?>
                        <?php 
                        $payments_total = get_student_payments_total($pdo, $tb['id']);
                        ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($tb['student_id']); ?></strong></td>
                            <td><?php echo htmlspecialchars($tb['first_name'] . ' ' . $tb['last_name']); ?></td>
                            <td><?php echo format_currency($tb['total_fees']); ?></td>
                            <td><?php echo format_currency($payments_total); ?></td>
                            <td><strong class="text-danger"><?php echo format_currency($tb['balance']); ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            <i class="fa-solid fa-check-double" style="font-size: 24px; margin-bottom: 10px; display: block; color: var(--success);"></i>
                            All accounts cleared! No students have outstanding balances.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
