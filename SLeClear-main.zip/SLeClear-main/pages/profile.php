<?php
// pages/profile.php
$page_title = "My Account Profile";
require_once __DIR__ . '/../includes/header.php';

// Handle password update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_pass = $_POST['current_password'] ?? '';
    $new_pass = $_POST['new_password'] ?? '';
    $confirm_pass = $_POST['confirm_password'] ?? '';
    
    // CSRF validation
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $_SESSION['flash_error'] = "Security validation failed. Please try again.";
        header("Location: /pages/profile.php");
        exit;
    }
    
    if (empty($current_pass) || empty($new_pass) || empty($confirm_pass)) {
        $_SESSION['flash_error'] = "All password fields are mandatory.";
    } elseif ($new_pass !== $confirm_pass) {
        $_SESSION['flash_error'] = "New passwords do not match.";
    } elseif (strlen($new_pass) < 6) {
        $_SESSION['flash_error'] = "New password must be at least 6 characters long.";
    } else {
        try {
            // Fetch password hash
            $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $current_hash = $stmt->fetchColumn();
            
            if ($current_hash && password_verify($current_pass, $current_hash)) {
                // Password matches, update
                $new_hash = password_hash($new_pass, PASSWORD_BCRYPT);
                $update = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $update->execute([$new_hash, $_SESSION['user_id']]);
                
                log_activity($pdo, $_SESSION['user_id'], 'Change Password', "User updated profile password");
                $_SESSION['flash_success'] = "Password changed successfully.";
                header("Location: /pages/profile.php");
                exit;
            } else {
                $_SESSION['flash_error'] = "Current password is incorrect.";
            }
        } catch (PDOException $e) {
            $_SESSION['flash_error'] = "Database error: " . $e->getMessage();
        }
    }
}

// Fetch user profile info
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    echo "<div class='alert alert-error'>Failed to load user info: " . $e->getMessage() . "</div>";
    $user = [];
}
?>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; max-width: 900px; margin: 0 auto;">
    <!-- Profile Info Card -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fa-solid fa-id-card"></i> Account Information</h3>
        </div>
        
        <div style="display: flex; flex-direction: column; align-items: center; padding: 20px; gap: 16px;">
            <div class="avatar" style="width: 80px; height: 80px; font-size: 28px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--info)); display: flex; align-items: center; justify-content: center; font-weight: 700; color: white; box-shadow: 0 4px 15px var(--primary-glow);">
                <?php echo strtoupper(substr($user['full_name'] ?? 'U', 0, 2)); ?>
            </div>
            
            <div style="text-align: center;">
                <h4 style="font-family: var(--font-heading); font-size: 18px; font-weight: 700;"><?php echo htmlspecialchars($user['full_name'] ?? ''); ?></h4>
                <span class="badge badge-role-<?php echo strtolower($user['role'] ?? ''); ?>" style="margin-top: 4px;"><?php echo htmlspecialchars($user['role'] ?? ''); ?></span>
            </div>
            
            <div style="width: 100%; border-top: 1px solid var(--border-color); padding-top: 16px; display: flex; flex-direction: column; gap: 12px; font-size: 14px;">
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: var(--text-muted);">Username:</span>
                    <strong><code><?php echo htmlspecialchars($user['username'] ?? ''); ?></code></strong>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: var(--text-muted);">Email Address:</span>
                    <strong><?php echo htmlspecialchars($user['email'] ?? 'N/A'); ?></strong>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: var(--text-muted);">System Status:</span>
                    <span class="badge badge-success">Active & Online</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: var(--text-muted);">Member Since:</span>
                    <strong><?php echo date('M d, Y', strtotime($user['created_at'] ?? 'now')); ?></strong>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Change Password Card -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fa-solid fa-key"></i> Update Security Credentials</h3>
        </div>
        
        <form action="/pages/profile.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <div class="form-group">
                <label for="current_password"><i class="fa-solid fa-unlock-keyhole"></i> Current Password *</label>
                <input type="password" id="current_password" name="current_password" placeholder="Enter current password" required autocomplete="current-password">
            </div>
            
            <div class="form-group">
                <label for="new_password"><i class="fa-solid fa-key"></i> New Password *</label>
                <input type="password" id="new_password" name="new_password" placeholder="Enter new password (min. 6 chars)" required autocomplete="new-password">
            </div>
            
            <div class="form-group">
                <label for="confirm_password"><i class="fa-solid fa-lock"></i> Confirm New Password *</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Repeat new password" required autocomplete="new-password">
            </div>
            
            <button type="submit" class="btn btn-primary btn-block" style="margin-top: 10px;">
                <i class="fa-solid fa-shield-halved"></i> Update Password
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
