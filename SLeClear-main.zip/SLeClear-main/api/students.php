<?php
// api/students.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Registry']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $_SESSION['flash_error'] = "Security validation failed. Please try again.";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/students.php'));
        exit;
    }

    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $student_id = trim($_POST['student_id'] ?? '');
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $faculty = trim($_POST['faculty'] ?? '');
    $level = trim($_POST['level'] ?? '');
    $academic_year = trim($_POST['academic_year'] ?? '');
    $total_fees = floatval($_POST['total_fees'] ?? 0);
    
    // Mandatory field check
    if (empty($student_id) || empty($first_name) || empty($last_name) || empty($department) || empty($faculty) || empty($level) || empty($academic_year)) {
        $_SESSION['flash_error'] = "All mandatory fields must be filled.";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/students.php'));
        exit;
    }

    // Strict email validation
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['flash_error'] = "Please enter a valid email address.";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/student_form.php'));
        exit;
    }

    // Phone number validation: Sierra Leone format (+232 XX XXXXXX or local 0XX XXXXXX)
    if (!empty($phone) && !preg_match('/^(\+232|0)[0-9\s\-]{7,14}$/', $phone)) {
        $_SESSION['flash_error'] = "Phone number must be a valid Sierra Leone format (e.g. +232 77 123456).";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/student_form.php'));
        exit;
    }

    // Fees must be non-negative
    if ($total_fees < 0) {
        $_SESSION['flash_error'] = "Total fees cannot be negative.";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/student_form.php'));
        exit;
    }

    try {
        if ($id) {
            // Non-Admins (Registry) cannot modify billing/fees. Get existing total_fees
            if (!has_role('Admin')) {
                $orig_stmt = $pdo->prepare("SELECT total_fees FROM students WHERE id = ?");
                $orig_stmt->execute([$id]);
                $total_fees = floatval($orig_stmt->fetchColumn() ?: 0.00);
            }

            // Update
            $stmt = $pdo->prepare("UPDATE students SET student_id = ?, first_name = ?, last_name = ?, email = ?, phone = ?, department = ?, faculty = ?, level = ?, academic_year = ?, total_fees = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$student_id, $first_name, $last_name, $email, $phone, $department, $faculty, $level, $academic_year, $total_fees, $id]);
            
            // Check clearance if fees total changed
            auto_clearance_check($pdo, $id, $_SESSION['user_id']);
            
            log_activity($pdo, $_SESSION['user_id'], 'Update Student', "Updated student $student_id ($first_name $last_name)");
            $_SESSION['flash_success'] = "Student information updated successfully.";
        } else {
            // Non-Admins (Registry) default to 0.00 fees on register
            if (!has_role('Admin')) {
                $total_fees = 0.00;
            }

            // Check uniqueness
            $chk = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id = ?");
            $chk->execute([$student_id]);
            if ($chk->fetchColumn() > 0) {
                $_SESSION['flash_error'] = "Student ID $student_id already exists.";
                header("Location: /pages/student_form.php");
                exit;
            }
            
            // Create
            $stmt = $pdo->prepare("INSERT INTO students (student_id, first_name, last_name, email, phone, department, faculty, level, academic_year, total_fees) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$student_id, $first_name, $last_name, $email, $phone, $department, $faculty, $level, $academic_year, $total_fees]);
            
            $new_student_id = $pdo->lastInsertId();
            
            // Auto clearance check (might be 0 fees)
            auto_clearance_check($pdo, $new_student_id, $_SESSION['user_id']);
            
            log_activity($pdo, $_SESSION['user_id'], 'Create Student', "Created student $student_id ($first_name $last_name)");
            $_SESSION['flash_success'] = "Student registered successfully.";
        }
        
        header("Location: /pages/students.php");
        exit;
    } catch (PDOException $e) {
        $_SESSION['flash_error'] = "Database error: " . $e->getMessage();
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/students.php'));
        exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    $id = isset($_GET['id']) ? intval($_GET['id']) : null;
    
    if ($action === 'delete' && $id) {
        require_role('Admin'); // Only Admins can delete
        
        try {
            // Get student info for log
            $stmt = $pdo->prepare("SELECT student_id, first_name, last_name FROM students WHERE id = ?");
            $stmt->execute([$id]);
            $student = $stmt->fetch();
            
            if ($student) {
                $del = $pdo->prepare("DELETE FROM students WHERE id = ?");
                $del->execute([$id]);
                
                log_activity($pdo, $_SESSION['user_id'], 'Delete Student', "Deleted student {$student['student_id']} ({$student['first_name']} {$student['last_name']})");
                $_SESSION['flash_success'] = "Student deleted successfully.";
            } else {
                $_SESSION['flash_error'] = "Student not found.";
            }
        } catch (PDOException $e) {
            $_SESSION['flash_error'] = "Database error: " . $e->getMessage();
        }
        header("Location: /pages/students.php");
        exit;
    }
}

header("Location: /pages/students.php");
exit;
?>
