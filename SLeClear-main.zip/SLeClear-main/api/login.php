<?php
// api/login.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $_SESSION['flash_error'] = "Security validation failed. Please try again.";
        header("Location: /index.php");
        exit;
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $_SESSION['flash_error'] = "Please enter both username and password.";
        header("Location: /index.php");
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Re-generate session ID to prevent session fixation
            session_regenerate_id(true);
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['last_activity'] = time();
            
            // Log successful login
            $logStmt = $pdo->prepare("INSERT INTO activity_log (user_id, action, details) VALUES (?, ?, ?)");
            $logStmt->execute([$user['id'], 'Login', "Successful login from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown')]);
            
            $_SESSION['flash_success'] = "Welcome back, " . $user['full_name'] . "!";
            header("Location: /pages/dashboard.php");
            exit;
        } else {
            // Log failed login attempt for audit trail
            $logStmt = $pdo->prepare("INSERT INTO activity_log (user_id, action, details) VALUES (?, ?, ?)");
            $logStmt->execute([null, 'Failed Login', "Failed login attempt for username '$username' from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown')]);

            $_SESSION['flash_error'] = "Invalid username or password.";
            header("Location: /index.php");
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['flash_error'] = "Database error during login: " . $e->getMessage();
        header("Location: /index.php");
        exit;
    }
} else {
    header("Location: /index.php");
    exit;
}
?>
