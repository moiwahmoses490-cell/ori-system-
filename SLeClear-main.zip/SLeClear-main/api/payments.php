<?php
// api/payments.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Finance']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $_SESSION['flash_error'] = "Security validation failed. Please try again.";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/payment_form.php'));
        exit;
    }

    $student_id = isset($_POST['student_id']) ? intval($_POST['student_id']) : null;
    $amount = floatval($_POST['amount'] ?? 0);
    $payment_date = trim($_POST['payment_date'] ?? '');
    $payment_method = trim($_POST['payment_method'] ?? '');
    $receipt_number = trim($_POST['receipt_number'] ?? '');
    $description = trim($_POST['description'] ?? '');
    
    if (empty($student_id) || $amount <= 0 || empty($payment_date) || empty($payment_method)) {
        $_SESSION['flash_error'] = "Please fill in all required fields and ensure amount is greater than zero.";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/payment_form.php'));
        exit;
    }

    // Validate payment method whitelist
    $allowed_methods = ['Cash', 'Bank Transfer', 'Mobile Money', 'Cheque'];
    if (!in_array($payment_method, $allowed_methods)) {
        $_SESSION['flash_error'] = "Invalid payment method selected.";
        header("Location: /pages/payment_form.php");
        exit;
    }

    try {
        // Begin transaction - ensures both insert and clearance check succeed or both roll back
        $pdo->beginTransaction();

        // Double-check if student exists
        $chk = $pdo->prepare("SELECT student_id, first_name, last_name FROM students WHERE id = ?");
        $chk->execute([$student_id]);
        $student = $chk->fetch();
        
        if (!$student) {
            $pdo->rollBack();
            $_SESSION['flash_error'] = "Invalid student selected.";
            header("Location: /pages/payment_form.php");
            exit;
        }

        // Insert payment record
        $stmt = $pdo->prepare("INSERT INTO payments (student_id, amount, payment_date, payment_method, receipt_number, description, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$student_id, $amount, $payment_date, $payment_method, $receipt_number, $description, $_SESSION['user_id']]);
        
        // Log transaction
        $formatted_amount = format_currency($amount);
        log_activity($pdo, $_SESSION['user_id'], 'Record Payment', "Recorded payment of $formatted_amount for student {$student['student_id']}");
        
        // Run automated clearance check within same transaction
        auto_clearance_check($pdo, $student_id, $_SESSION['user_id']);

        // All steps completed, commit
        $pdo->commit();
        
        $_SESSION['flash_success'] = "Payment of $formatted_amount registered successfully.";
        header("Location: /pages/payments.php");
        exit;
    } catch (PDOException $e) {
        // Roll back any partial changes
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['flash_error'] = "Database error: " . $e->getMessage();
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/payment_form.php'));
        exit;
    }
}

header("Location: /pages/payments.php");
exit;
?>
