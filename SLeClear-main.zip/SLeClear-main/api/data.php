<?php
// api/data.php — SLeClear MIS Public JSON Interoperability API
// Read-only. Requires valid session authentication.
// Endpoint: GET /api/data.php?resource=students|payments|clearances|summary

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=UTF-8');
header('X-Content-Type-Options: nosniff');

// Must be logged in to access data API
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized. Authentication required.', 'code' => 401]);
    exit;
}

$resource = trim($_GET['resource'] ?? '');
$allowed_resources = ['students', 'payments', 'clearances', 'summary'];

if (!in_array($resource, $allowed_resources)) {
    http_response_code(400);
    echo json_encode([
        'error' => 'Invalid or missing resource parameter.',
        'code' => 400,
        'allowed' => $allowed_resources,
        'example' => '/api/data.php?resource=summary'
    ]);
    exit;
}

try {
    switch ($resource) {
        
        // ── Students ──────────────────────────────────────────────
        case 'students':
            require_role(['Admin', 'Registry']);
            $limit = min(intval($_GET['limit'] ?? 100), 500);
            $offset = max(0, intval($_GET['offset'] ?? 0));

            // Admin gets full record; Registry gets academic fields only (no fee data)
            if (has_role('Admin')) {
                $stmt = $pdo->prepare("SELECT id, student_id, first_name, last_name, department, faculty, level, academic_year, total_fees, created_at FROM students ORDER BY id ASC LIMIT ? OFFSET ?");
            } else {
                $stmt = $pdo->prepare("SELECT id, student_id, first_name, last_name, department, faculty, level, academic_year, created_at FROM students ORDER BY id ASC LIMIT ? OFFSET ?");
            }
            $stmt->bindValue(1, $limit, PDO::PARAM_INT);
            $stmt->bindValue(2, $offset, PDO::PARAM_INT);
            $stmt->execute();
            $students = $stmt->fetchAll();

            // Only Admins get financial balance fields
            if (has_role('Admin')) {
                foreach ($students as &$s) {
                    $s['outstanding_balance'] = get_student_balance($pdo, $s['id']);
                    $s['paid_total'] = get_student_payments_total($pdo, $s['id']);
                }
                unset($s);
            }

            $total = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();

            echo json_encode([
                'resource' => 'students',
                'total' => (int)$total,
                'limit' => $limit,
                'offset' => $offset,
                'data' => $students
            ], JSON_PRETTY_PRINT);
            break;

        // ── Payments ──────────────────────────────────────────────
        case 'payments':
            require_role(['Admin', 'Finance']);
            $limit = min(intval($_GET['limit'] ?? 100), 500);
            $offset = max(0, intval($_GET['offset'] ?? 0));

            $stmt = $pdo->prepare("SELECT p.id, p.amount, p.payment_date, p.payment_method, p.receipt_number, p.description, p.created_at,
                                          s.student_id, s.first_name, s.last_name
                                   FROM payments p 
                                   JOIN students s ON p.student_id = s.id 
                                   ORDER BY p.id DESC LIMIT ? OFFSET ?");
            $stmt->bindValue(1, $limit, PDO::PARAM_INT);
            $stmt->bindValue(2, $offset, PDO::PARAM_INT);
            $stmt->execute();
            $payments = $stmt->fetchAll();

            $total = $pdo->query("SELECT COUNT(*) FROM payments")->fetchColumn();
            $total_amount = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM payments")->fetchColumn();

            echo json_encode([
                'resource' => 'payments',
                'total' => (int)$total,
                'total_amount_collected' => round((float)$total_amount, 2),
                'limit' => $limit,
                'offset' => $offset,
                'data' => $payments
            ], JSON_PRETTY_PRINT);
            break;

        // ── Clearances ────────────────────────────────────────────
        case 'clearances':
            require_role(['Admin', 'Finance', 'Registry']);
            $status_filter = trim($_GET['status'] ?? '');
            $allowed_statuses = ['', 'Cleared', 'Pending', 'Provisional', 'Denied'];
            if (!in_array($status_filter, $allowed_statuses)) {
                $status_filter = '';
            }

            if ($status_filter) {
                $stmt = $pdo->prepare("SELECT c.id, c.academic_year, c.semester, c.status, c.notes, c.cleared_at,
                                              s.student_id, s.first_name, s.last_name, s.department, s.faculty, s.level
                                       FROM clearances c 
                                       JOIN students s ON c.student_id = s.id 
                                       WHERE c.status = ?
                                       ORDER BY c.id DESC");
                $stmt->execute([$status_filter]);
            } else {
                $stmt = $pdo->query("SELECT c.id, c.academic_year, c.semester, c.status, c.notes, c.cleared_at,
                                            s.student_id, s.first_name, s.last_name, s.department, s.faculty, s.level
                                     FROM clearances c 
                                     JOIN students s ON c.student_id = s.id 
                                     ORDER BY c.id DESC");
            }
            $clearances = $stmt->fetchAll();

            echo json_encode([
                'resource' => 'clearances',
                'filter_status' => $status_filter ?: 'all',
                'count' => count($clearances),
                'data' => $clearances
            ], JSON_PRETTY_PRINT);
            break;

        // ── Summary / Dashboard Snapshot ──────────────────────────
        case 'summary':
            require_role(['Admin', 'Finance', 'Registry']);
            $total_students = (int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
            $total_deferred = (int)$pdo->query("SELECT COUNT(*) FROM deferred_assessments")->fetchColumn();

            // Clearance breakdown — available to all roles
            $cl_row = $pdo->query("SELECT status, COUNT(*) as cnt FROM clearances GROUP BY status")->fetchAll();
            $clearance_breakdown = [];
            foreach ($cl_row as $row) {
                $clearance_breakdown[$row['status']] = (int)$row['cnt'];
            }

            $totals = [
                'students' => $total_students,
                'deferred_applications' => $total_deferred,
            ];

            // Financial totals are Admin & Finance only
            if (has_role(['Admin', 'Finance'])) {
                $total_payments = (int)$pdo->query("SELECT COUNT(*) FROM payments")->fetchColumn();
                $total_collected = round((float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM payments")->fetchColumn(), 2);

                // Total outstanding
                $all_students = $pdo->query("SELECT id, total_fees FROM students")->fetchAll();
                $total_outstanding = 0.0;
                foreach ($all_students as $s) {
                    $total_outstanding += get_student_balance($pdo, $s['id']);
                }

                $totals['payments'] = $total_payments;
                $totals['collected_leones'] = $total_collected;
                $totals['outstanding_leones'] = round($total_outstanding, 2);
            }

            echo json_encode([
                'resource' => 'summary',
                'generated_at' => date('Y-m-d\TH:i:s\Z'),
                'system' => 'SLeClear MIS — Sierra Leone Student Clearance & Financial MIS',
                'academic_year' => date('Y') . '/' . (date('Y') + 1),
                'totals' => $totals,
                'clearance_breakdown' => $clearance_breakdown,
                'sdg_alignment' => [
                    'SDG_4' => 'Quality Education — Removing financial barriers to academic progression',
                    'SDG_10' => 'Reduced Inequalities — Transparent, accessible clearance for all students',
                ]
            ], JSON_PRETTY_PRINT);
            break;
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error.', 'code' => 500]);
}
?>
