<?php
// api/clearances.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Finance', 'Registry']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $_SESSION['flash_error'] = "Security validation failed. Please try again.";
        header("Location: /pages/clearances.php");
        exit;
    }

    $clearance_id = isset($_POST['clearance_id']) ? intval($_POST['clearance_id']) : null;
    $student_id = isset($_POST['student_id']) ? intval($_POST['student_id']) : null;
    $academic_year = trim($_POST['academic_year'] ?? '');
    $semester = trim($_POST['semester'] ?? 'Semester 1');
    $status = trim($_POST['status'] ?? 'Pending');
    $notes = trim($_POST['notes'] ?? '');

    // Whitelist status values
    $allowed_statuses = ['Cleared', 'Pending', 'Provisional', 'Denied'];
    if (!in_array($status, $allowed_statuses)) {
        $_SESSION['flash_error'] = "Invalid status value.";
        header("Location: /pages/clearances.php");
        exit;
    }
    
    // Authorization check: only Admin and Finance can change status
    if (!has_role(['Admin', 'Finance']) && has_role('Registry')) {
        if ($clearance_id) {
            $chk = $pdo->prepare("SELECT status FROM clearances WHERE id = ?");
            $chk->execute([$clearance_id]);
            $curr_status = $chk->fetchColumn();
            if ($curr_status !== $status) {
                $_SESSION['flash_error'] = "Registry staff cannot change clearance status. Only Admin or Finance users can perform this override.";
                header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/clearances.php'));
                exit;
            }
        } else {
            $_SESSION['flash_error'] = "Registry staff cannot create or change clearance status.";
            header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/clearances.php'));
            exit;
        }
    }

    if (empty($student_id) || empty($academic_year) || empty($semester)) {
        $_SESSION['flash_error'] = "Required fields are missing.";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/pages/clearances.php'));
        exit;
    }

    try {
        if ($clearance_id) {
            // Update existing record
            $stmt = $pdo->prepare("UPDATE clearances SET status = ?, notes = ?, cleared_by = ?, cleared_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$status, $notes, $_SESSION['user_id'], $clearance_id]);
            
            $sInfo = $pdo->prepare("SELECT s.student_id FROM clearances c JOIN students s ON c.student_id = s.id WHERE c.id = ?");
            $sInfo->execute([$clearance_id]);
            $student_id_text = $sInfo->fetchColumn();
            
            log_activity($pdo, $_SESSION['user_id'], 'Update Clearance', "Updated clearance for student $student_id_text to status '$status'");
            $_SESSION['flash_success'] = "Clearance updated successfully.";
        } else {
            // Upsert
            $chk = $pdo->prepare("SELECT id FROM clearances WHERE student_id = ? AND academic_year = ? AND semester = ?");
            $chk->execute([$student_id, $academic_year, $semester]);
            $existing_id = $chk->fetchColumn();
            
            if ($existing_id) {
                $stmt = $pdo->prepare("UPDATE clearances SET status = ?, notes = ?, cleared_by = ?, cleared_at = CURRENT_TIMESTAMP WHERE id = ?");
                $stmt->execute([$status, $notes, $_SESSION['user_id'], $existing_id]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO clearances (student_id, academic_year, semester, status, notes, cleared_by, cleared_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
                $stmt->execute([$student_id, $academic_year, $semester, $status, $notes, $_SESSION['user_id']]);
            }
            
            log_activity($pdo, $_SESSION['user_id'], 'Create Clearance', "Set clearance for student ID $student_id to status '$status'");
            $_SESSION['flash_success'] = "Clearance status established successfully.";
        }
    } catch (PDOException $e) {
        $_SESSION['flash_error'] = "Database error: " . $e->getMessage();
    }
    
    header("Location: /pages/clearances.php");
    exit;
}

header("Location: /pages/clearances.php");
exit;
?>
