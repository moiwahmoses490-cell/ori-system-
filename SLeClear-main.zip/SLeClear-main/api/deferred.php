<?php
// api/deferred.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Finance', 'Registry']);

// Ensure uploads directory exists
$upload_dir = __DIR__ . '/../uploads/deferred/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
        $_SESSION['flash_error'] = "Security validation failed. Please try again.";
        header("Location: /pages/deferred.php");
        exit;
    }

    $action = $_POST['action'] ?? '';
    
    // 1. Submit Application
    if ($action === 'submit') {
        $student_id = isset($_POST['student_id']) ? intval($_POST['student_id']) : null;
        $course_code = strtoupper(trim($_POST['course_code'] ?? ''));
        $course_name = trim($_POST['course_name'] ?? '');
        $reason = trim($_POST['reason'] ?? '');
        $fee_amount = floatval($_POST['fee_amount'] ?? 150.00);
        $fee_paid = isset($_POST['fee_paid']) ? 1 : 0;
        
        if (empty($student_id) || empty($course_code) || empty($course_name) || empty($reason)) {
            $_SESSION['flash_error'] = "All fields are required to submit deferred exam application.";
            header("Location: /pages/deferred_form.php");
            exit;
        }

        // Handle file upload
        $document_path = null;
        if (isset($_FILES['supporting_doc']) && $_FILES['supporting_doc']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['supporting_doc'];
            $max_size = 5 * 1024 * 1024; // 5MB
            $allowed_types = ['application/pdf', 'image/jpeg', 'image/png', 'application/msword',
                              'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
            $allowed_exts = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            if ($file['size'] > $max_size) {
                $_SESSION['flash_error'] = "Supporting document exceeds the 5MB file size limit.";
                header("Location: /pages/deferred_form.php");
                exit;
            }

            if (!in_array($ext, $allowed_exts) || !in_array($file['type'], $allowed_types)) {
                $_SESSION['flash_error'] = "Unsupported file type. Please upload a PDF, image, or Word document.";
                header("Location: /pages/deferred_form.php");
                exit;
            }

            // Generate unique filename: studentid_coursecode_timestamp.ext
            $safe_name = preg_replace('/[^a-zA-Z0-9_\-]/', '_', "def_{$student_id}_{$course_code}") . '_' . time() . '.' . $ext;
            $target_path = $upload_dir . $safe_name;

            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                $document_path = 'uploads/deferred/' . $safe_name;
            } else {
                $_SESSION['flash_error'] = "Failed to save the uploaded document. Please try again.";
                header("Location: /pages/deferred_form.php");
                exit;
            }
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO deferred_assessments (student_id, course_code, course_name, reason, fee_amount, fee_paid, document_path, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')");
            $stmt->execute([$student_id, $course_code, $course_name, $reason, $fee_amount, $fee_paid, $document_path]);
            
            $sInfo = $pdo->prepare("SELECT student_id FROM students WHERE id = ?");
            $sInfo->execute([$student_id]);
            $student_id_text = $sInfo->fetchColumn();
            
            log_activity($pdo, $_SESSION['user_id'], 'Apply Deferral', "Submitted deferred assessment application for $student_id_text - $course_code");
            $_SESSION['flash_success'] = "Deferred assessment application submitted successfully.";
        } catch (PDOException $e) {
            $_SESSION['flash_error'] = "Database error: " . $e->getMessage();
        }
        header("Location: /pages/deferred.php");
        exit;
    }
    
    // 2. Review Application (Approve / Deny / Mark Fee Paid)
    if ($action === 'review') {
        require_role(['Admin', 'Finance']); // Registry cannot review/approve
        
        $id = isset($_POST['id']) ? intval($_POST['id']) : null;
        $status = trim($_POST['status'] ?? 'Pending');
        $fee_paid = isset($_POST['fee_paid']) ? 1 : 0;

        // Whitelist status
        $allowed_statuses = ['Pending', 'Approved', 'Denied'];
        if (!in_array($status, $allowed_statuses)) {
            $_SESSION['flash_error'] = "Invalid status value.";
            header("Location: /pages/deferred.php");
            exit;
        }
        
        if (!$id) {
            $_SESSION['flash_error'] = "Invalid application identifier.";
            header("Location: /pages/deferred.php");
            exit;
        }

        try {
            $stmt = $pdo->prepare("UPDATE deferred_assessments SET status = ?, fee_paid = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$status, $fee_paid, $_SESSION['user_id'], $id]);
            
            log_activity($pdo, $_SESSION['user_id'], 'Review Deferral', "Reviewed deferral application ID $id (Status: $status, Paid: $fee_paid)");
            $_SESSION['flash_success'] = "Deferred assessment application updated successfully.";
        } catch (PDOException $e) {
            $_SESSION['flash_error'] = "Database error: " . $e->getMessage();
        }
        header("Location: /pages/deferred.php");
        exit;
    }
}

header("Location: /pages/deferred.php");
exit;
?>
