<?php
// api/export.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_role(['Admin', 'Finance', 'Registry']);

$type = $_GET['type'] ?? 'csv';
$report = $_GET['report'] ?? '';

// CSV Export logic
if ($type === 'csv') {
    $filename = "sleclear_" . (!empty($report) ? $report : "export") . "_" . date('Ymd_His') . ".csv";
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    
    $output = fopen('php://output', 'w');
    
    if ($report === 'students') {
        // Output headers
        fputcsv($output, ['ID', 'Student ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Department', 'Faculty', 'Level', 'Academic Year', 'Total Fees', 'Outstanding Balance']);
        
        $query = "SELECT id, student_id, first_name, last_name, email, phone, department, faculty, level, academic_year, total_fees FROM students";
        $stmt = $pdo->query($query);
        while ($row = $stmt->fetch()) {
            $balance = get_student_balance($pdo, $row['id']);
            fputcsv($output, [
                $row['id'],
                $row['student_id'],
                $row['first_name'],
                $row['last_name'],
                $row['email'],
                $row['phone'],
                $row['department'],
                $row['faculty'],
                $row['level'],
                $row['academic_year'],
                $row['total_fees'],
                $balance
            ]);
        }
    } elseif ($report === 'payments') {
        fputcsv($output, ['Payment ID', 'Student ID', 'Student Name', 'Amount', 'Payment Date', 'Payment Method', 'Receipt Number', 'Description', 'Recorded By']);
        
        $query = "SELECT p.id, s.student_id, s.first_name, s.last_name, p.amount, p.payment_date, p.payment_method, p.receipt_number, p.description, u.full_name as recorder 
                  FROM payments p 
                  JOIN students s ON p.student_id = s.id 
                  JOIN users u ON p.recorded_by = u.id";
        $stmt = $pdo->query($query);
        while ($row = $stmt->fetch()) {
            fputcsv($output, [
                $row['id'],
                $row['student_id'],
                $row['first_name'] . ' ' . $row['last_name'],
                $row['amount'],
                $row['payment_date'],
                $row['payment_method'],
                $row['receipt_number'],
                $row['description'],
                $row['recorder']
            ]);
        }
    } elseif ($report === 'clearances') {
        fputcsv($output, ['Clearance ID', 'Student ID', 'Student Name', 'Department', 'Academic Year', 'Semester', 'Status', 'Cleared By', 'Cleared At', 'Notes']);
        
        $query = "SELECT c.id, s.student_id, s.first_name, s.last_name, s.department, c.academic_year, c.semester, c.status, u.full_name as officer, c.cleared_at, c.notes 
                  FROM clearances c 
                  JOIN students s ON c.student_id = s.id 
                  LEFT JOIN users u ON c.cleared_by = u.id";
        $stmt = $pdo->query($query);
        while ($row = $stmt->fetch()) {
            fputcsv($output, [
                $row['id'],
                $row['student_id'],
                $row['first_name'] . ' ' . $row['last_name'],
                $row['department'],
                $row['academic_year'],
                $row['semester'],
                $row['status'],
                $row['officer'] ?? 'System',
                $row['cleared_at'] ?? 'N/A',
                $row['notes']
            ]);
        }
    } else {
        fputcsv($output, ['Error', 'Invalid Report Selection']);
    }
    
    fclose($output);
    exit;
}

// If no action matched, redirect to dashboard
header("Location: /pages/dashboard.php");
exit;
?>
