// assets/js/app.js

document.addEventListener('DOMContentLoaded', function() {
    
    // Dynamic Table Row Filtering
    const searchInput = document.getElementById('table-search');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const query = e.target.value.toLowerCase();
            const tableRows = document.querySelectorAll('table tbody tr:not(.no-results)');
            let matches = 0;
            
            tableRows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(query)) {
                    row.style.display = '';
                    matches++;
                } else {
                    row.style.display = 'none';
                }
            });
            
            // Check if we need to show a "No results found" row
            const tbody = document.querySelector('table tbody');
            let noResultsRow = document.querySelector('table tbody tr.no-results');
            
            if (matches === 0) {
                if (!noResultsRow) {
                    noResultsRow = document.createElement('tr');
                    noResultsRow.className = 'no-results';
                    const colsCount = document.querySelectorAll('table th').length || 10;
                    noResultsRow.innerHTML = `<td colspan="${colsCount}" style="text-align: center; color: var(--text-muted); padding: 30px;">
                        <i class="fa-solid fa-magnifying-glass" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                        No matching records found.
                    </td>`;
                    tbody.appendChild(noResultsRow);
                } else {
                    noResultsRow.style.display = '';
                }
            } else if (noResultsRow) {
                noResultsRow.style.display = 'none';
            }
        });
    }

    // Dynamic Dropdown Filtering (e.g. for Status or Department)
    const filterSelects = document.querySelectorAll('.table-filter');
    filterSelects.forEach(select => {
        select.addEventListener('change', function() {
            filterTable();
        });
    });

    function filterTable() {
        const filters = [];
        filterSelects.forEach(select => {
            const filterCol = parseInt(select.getAttribute('data-column'));
            const filterVal = select.value.toLowerCase();
            if (filterVal !== '') {
                filters.push({ col: filterCol, val: filterVal });
            }
        });

        const tableRows = document.querySelectorAll('table tbody tr:not(.no-results)');
        let matches = 0;

        tableRows.forEach(row => {
            let showRow = true;
            
            filters.forEach(f => {
                const td = row.cells[f.col];
                if (td) {
                    const cellText = td.textContent.trim().toLowerCase();
                    if (f.val === 'cleared' && cellText.includes('cleared')) {
                        // match
                    } else if (f.val === 'pending' && cellText.includes('pending')) {
                        // match
                    } else if (cellText !== f.val && !cellText.includes(f.val)) {
                        showRow = false;
                    }
                }
            });

            if (showRow) {
                row.style.display = '';
                matches++;
            } else {
                row.style.display = 'none';
            }
        });

        // Toggle No Results
        const tbody = document.querySelector('table tbody');
        let noResultsRow = document.querySelector('table tbody tr.no-results');
        if (matches === 0) {
            if (!noResultsRow && tbody) {
                noResultsRow = document.createElement('tr');
                noResultsRow.className = 'no-results';
                const colsCount = document.querySelectorAll('table th').length || 10;
                noResultsRow.innerHTML = `<td colspan="${colsCount}" style="text-align: center; color: var(--text-muted); padding: 30px;">No matching records found.</td>`;
                tbody.appendChild(noResultsRow);
            } else if (noResultsRow) {
                noResultsRow.style.display = '';
            }
        } else if (noResultsRow) {
            noResultsRow.style.display = 'none';
        }
    }
    
    // Auto-calculating Fee Balances in Payments / Deferred forms
    const studentSelect = document.getElementById('student_id_select');
    if (studentSelect) {
        studentSelect.addEventListener('change', function() {
            const selectedOpt = this.options[this.selectedIndex];
            const balance = selectedOpt.getAttribute('data-balance');
            const totalFees = selectedOpt.getAttribute('data-fees');
            
            const balInput = document.getElementById('current_balance');
            const feesInput = document.getElementById('total_fees');
            const payInput = document.getElementById('amount');
            
            if (balInput) balInput.value = balance ? parseFloat(balance).toFixed(2) : '0.00';
            if (feesInput) feesInput.value = totalFees ? parseFloat(totalFees).toFixed(2) : '0.00';
            
            // Default payment amount to full outstanding balance if positive
            if (payInput && balance && parseFloat(balance) > 0) {
                payInput.value = parseFloat(balance).toFixed(2);
            }
        });
    }

    // Confirmation dialogues
    const confirmActions = document.querySelectorAll('.confirm-action');
    confirmActions.forEach(el => {
        el.addEventListener('click', function(e) {
            const msg = this.getAttribute('data-confirm-message') || "Are you sure you want to perform this action?";
            if (!confirm(msg)) {
                e.preventDefault();
            }
        });
    });
});

// Helper for print
function printSlip() {
    window.print();
}
